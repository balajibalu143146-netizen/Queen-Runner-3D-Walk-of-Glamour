/**
 * 5 Progressive Level Definitions for Queen Runner 3D
 * Configures runway length, run speed, gate distributions, coin layouts,
 * gems, mud obstacles, and thematic progression.
 */

const GAME_LEVELS = [
    // --- LEVEL 1: The Debutante Walk ---
    {
        id: 1,
        title: "The Debutante Walk",
        subtitle: "Palace Gardens",
        length: 170,
        speed: 11.5,
        targetGlamour: 65,
        description: "Begin your royal journey! Collect stylish accessories and transform from casual to chic.",
        gates: [
            {
                z: 35,
                left: { text: "GLOW UP", delta: 25, isPositive: true },
                right: { text: "BEDHEAD", delta: -15, isPositive: false }
            },
            {
                z: 75,
                left: { text: "DIRTY TEE", delta: -20, isPositive: false },
                right: { text: "CHIC DRESS", delta: 30, isPositive: true }
            },
            {
                z: 115,
                left: { text: "ROYAL HEELS", delta: 30, isPositive: true },
                right: { text: "SLIPPERS", delta: -20, isPositive: false }
            },
            {
                z: 145,
                left: { text: "WILTED ROSE", delta: -25, isPositive: false },
                right: { text: "TIARA GLOW", delta: 35, isPositive: true }
            }
        ],
        coins: [
            { type: "line", x: -1.6, startZ: 12, count: 6 },
            { type: "line", x: 1.6, startZ: 50, count: 6 },
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 90, count: 8 },
            { type: "line", x: 1.6, startZ: 130, count: 5 }
        ],
        gems: [
            { x: 0, z: 25, type: "ruby" },
            { x: 0, z: 100, type: "cyan" }
        ],
        hazards: []
    },

    // --- LEVEL 2: High Fashion Promenade ---
    {
        id: 2,
        title: "Fashion Promenade",
        subtitle: "Gilded Boulevard",
        length: 230,
        speed: 13.0,
        targetGlamour: 80,
        description: "Step into the spotlight! Dodge the paparazzi mud and choose haute couture over messy habits.",
        gates: [
            {
                z: 32,
                left: { text: "FAST FOOD", delta: -20, isPositive: false },
                right: { text: "SUPERMODEL", delta: 25, isPositive: true }
            },
            {
                z: 68,
                left: { text: "DESIGNER BAG", delta: 30, isPositive: true },
                right: { text: "PLASTIC BAG", delta: -20, isPositive: false }
            },
            {
                z: 105,
                left: { text: "TORN JEANS", delta: -25, isPositive: false },
                right: { text: "SILK SKIRT", delta: 30, isPositive: true }
            },
            {
                z: 142,
                left: { text: "GOLD CHOKER", delta: 35, isPositive: true },
                right: { text: "RUSTY CHAIN", delta: -25, isPositive: false }
            },
            {
                z: 178,
                left: { text: "LAZY COUCH", delta: -30, isPositive: false },
                right: { text: "ROYAL POISE", delta: 40, isPositive: true }
            },
            {
                z: 206,
                left: { text: "GALA GOWN", delta: 45, isPositive: true },
                right: { text: "MUDDY HOODIE", delta: -30, isPositive: false }
            }
        ],
        coins: [
            { type: "line", x: 1.6, startZ: 15, count: 5 },
            { type: "arc", startX: 1.6, endX: -1.6, startZ: 45, count: 7 },
            { type: "line", x: -1.6, startZ: 85, count: 6 },
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 120, count: 7 },
            { type: "line", x: 1.6, startZ: 158, count: 6 }
        ],
        gems: [
            { x: -1.6, z: 22, type: "ruby" },
            { x: 1.6, z: 95, type: "cyan" },
            { x: 0, z: 195, type: "ruby" }
        ],
        hazards: [
            { x: 0, z: 52 },
            { x: -1.6, z: 128 },
            { x: 1.6, z: 168 }
        ]
    },

    // --- LEVEL 3: The Royal Gala ---
    {
        id: 3,
        title: "The Royal Gala",
        subtitle: "Imperial Plaza",
        length: 300,
        speed: 15.0,
        targetGlamour: 95,
        description: "Watch out for moving gates! Master high-speed catwalk maneuvers to maintain your queen status.",
        gates: [
            {
                z: 32,
                left: { text: "PERFUME MIST", delta: 30, isPositive: true },
                right: { text: "SOUR DRAMA", delta: -25, isPositive: false }
            },
            {
                z: 68,
                isMoving: true,
                moveSpeed: 2.2,
                moveAmp: 0.7,
                left: { text: "STILETTOS", delta: 35, isPositive: true },
                right: { text: "WORN SNEAKS", delta: -25, isPositive: false }
            },
            {
                z: 104,
                left: { text: "SLEEPY SLOUCH", delta: -30, isPositive: false },
                right: { text: "EMPRESS AURA", delta: 40, isPositive: true }
            },
            {
                z: 140,
                left: { text: "DIAMONDS", delta: 45, isPositive: true },
                right: { text: "FAKE BLING", delta: -30, isPositive: false }
            },
            {
                z: 178,
                isMoving: true,
                moveSpeed: 2.5,
                moveAmp: 0.8,
                left: { text: "CHEAP GOSSIP", delta: -35, isPositive: false },
                right: { text: "PRINCESSE VOGUE", delta: 45, isPositive: true }
            },
            {
                z: 215,
                left: { text: "RUBY NECKLACE", delta: 40, isPositive: true },
                right: { text: "BURNT COFFEE", delta: -25, isPositive: false }
            },
            {
                z: 250,
                left: { text: "MUD PUDDLE", delta: -35, isPositive: false },
                right: { text: "VELVET CAPE", delta: 50, isPositive: true }
            },
            {
                z: 280,
                left: { text: "CORONATION GALA", delta: 50, isPositive: true },
                right: { text: "EXCUSES", delta: -40, isPositive: false }
            }
        ],
        coins: [
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 14, count: 6 },
            { type: "line", x: 0, startZ: 48, count: 6 },
            { type: "arc", startX: 1.6, endX: -1.6, startZ: 85, count: 7 },
            { type: "line", x: -1.6, startZ: 122, count: 6 },
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 156, count: 8 },
            { type: "line", x: 1.6, startZ: 195, count: 6 },
            { type: "arc", startX: 1.6, endX: -1.6, startZ: 232, count: 7 }
        ],
        gems: [
            { x: 1.6, z: 25, type: "cyan" },
            { x: -1.6, z: 115, type: "ruby" },
            { x: 0, z: 188, type: "ruby" },
            { x: 1.6, z: 265, type: "cyan" }
        ],
        hazards: [
            { x: 0, z: 54 },
            { x: -1.6, z: 92 },
            { x: 1.6, z: 132 },
            { x: 0, z: 170 },
            { x: -1.6, z: 240 }
        ]
    },

    // --- LEVEL 4: Chamber of Mirrors ---
    {
        id: 4,
        title: "Chamber of Mirrors",
        subtitle: "Rose Gold Palace",
        length: 360,
        speed: 17.0,
        targetGlamour: 110,
        description: "Rapid decisions and treacherous temptations. Only true royalty can shine through!",
        gates: [
            {
                z: 32,
                left: { text: "TOXIC VIBES", delta: -30, isPositive: false },
                right: { text: "CRYSTAL HEELS", delta: 35, isPositive: true }
            },
            {
                z: 66,
                isMoving: true,
                moveSpeed: 2.8,
                moveAmp: 0.9,
                left: { text: "GOLDEN TIARA", delta: 40, isPositive: true },
                right: { text: "DUSTY CLOSET", delta: -30, isPositive: false }
            },
            {
                z: 102,
                left: { text: "SMUDGED LINER", delta: -30, isPositive: false },
                right: { text: "GLAMOUR GLOW", delta: 40, isPositive: true }
            },
            {
                z: 138,
                left: { text: "ROYAL BALLGOWN", delta: 45, isPositive: true },
                right: { text: "TORN SWEATER", delta: -35, isPositive: false }
            },
            {
                z: 174,
                isMoving: true,
                moveSpeed: 3.0,
                moveAmp: 1.0,
                left: { text: "BAD ATTITUDE", delta: -40, isPositive: false },
                right: { text: "DIVA CONFIDENCE", delta: 50, isPositive: true }
            },
            {
                z: 210,
                left: { text: "SAPPHIRE TIARA", delta: 45, isPositive: true },
                right: { text: "CHEAP PLASTIC", delta: -35, isPositive: false }
            },
            {
                z: 246,
                left: { text: "STREET TRASH", delta: -40, isPositive: false },
                right: { text: "EMPRESS GALA", delta: 50, isPositive: true }
            },
            {
                z: 282,
                isMoving: true,
                moveSpeed: 3.2,
                moveAmp: 1.0,
                left: { text: "VELVET SASH", delta: 50, isPositive: true },
                right: { text: "SPILLED SOUP", delta: -35, isPositive: false }
            },
            {
                z: 318,
                left: { text: "TIRED SLOUCH", delta: -40, isPositive: false },
                right: { text: "MAJESTIC WALK", delta: 55, isPositive: true }
            },
            {
                z: 345,
                left: { text: "QUEEN CROWN", delta: 60, isPositive: true },
                right: { text: "QUITTING NOW", delta: -50, isPositive: false }
            }
        ],
        coins: [
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 15, count: 7 },
            { type: "arc", startX: 1.6, endX: -1.6, startZ: 48, count: 7 },
            { type: "line", x: 1.6, startZ: 85, count: 6 },
            { type: "line", x: -1.6, startZ: 120, count: 6 },
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 155, count: 7 },
            { type: "line", x: 0, startZ: 192, count: 6 },
            { type: "arc", startX: 1.6, endX: -1.6, startZ: 228, count: 7 },
            { type: "line", x: 1.6, startZ: 265, count: 6 },
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 300, count: 7 }
        ],
        gems: [
            { x: 0, z: 22, type: "ruby" },
            { x: 1.6, z: 92, type: "cyan" },
            { x: -1.6, z: 165, type: "ruby" },
            { x: 1.6, z: 236, type: "cyan" },
            { x: 0, z: 330, type: "ruby" }
        ],
        hazards: [
            { x: -1.6, z: 54 },
            { x: 1.6, z: 112 },
            { x: 0, z: 148 },
            { x: -1.6, z: 200 },
            { x: 1.6, z: 256 },
            { x: 0, z: 292 }
        ]
    },

    // --- LEVEL 5: The Grand Coronation ---
    {
        id: 5,
        title: "The Grand Coronation",
        subtitle: "Imperial Citadel",
        length: 440,
        speed: 19.0,
        targetGlamour: 130,
        description: "The ultimate royal trial! Race down the grand imperial catwalk to claim the Diamond Crown and Throne!",
        gates: [
            {
                z: 32,
                left: { text: "ROYAL ENTRANCE", delta: 35, isPositive: true },
                right: { text: "STUMBLE", delta: -30, isPositive: false }
            },
            {
                z: 66,
                isMoving: true,
                moveSpeed: 3.2,
                moveAmp: 1.0,
                left: { text: "POOR POSTURE", delta: -35, isPositive: false },
                right: { text: "DIAMOND HEELS", delta: 45, isPositive: true }
            },
            {
                z: 102,
                left: { text: "GOLDEN SASH", delta: 45, isPositive: true },
                right: { text: "DIRT STAIN", delta: -35, isPositive: false }
            },
            {
                z: 138,
                isMoving: true,
                moveSpeed: 3.5,
                moveAmp: 1.1,
                left: { text: "FEAR & DOUBT", delta: -40, isPositive: false },
                right: { text: "EMPRESS CONFIDENCE", delta: 50, isPositive: true }
            },
            {
                z: 174,
                left: { text: "HAUTE GOWN", delta: 50, isPositive: true },
                right: { text: "RAGS", delta: -40, isPositive: false }
            },
            {
                z: 210,
                isMoving: true,
                moveSpeed: 3.6,
                moveAmp: 1.1,
                left: { text: "JEALOUS HATERS", delta: -45, isPositive: false },
                right: { text: "SAPPHIRE DIADEM", delta: 55, isPositive: true }
            },
            {
                z: 248,
                left: { text: "VELVET TRAIN", delta: 55, isPositive: true },
                right: { text: "TRIP HAZARD", delta: -40, isPositive: false }
            },
            {
                z: 285,
                isMoving: true,
                moveSpeed: 3.8,
                moveAmp: 1.2,
                left: { text: "GIVING UP", delta: -50, isPositive: false },
                right: { text: "ROYAL SCEPTER", delta: 60, isPositive: true }
            },
            {
                z: 322,
                left: { text: "CHEAP GADGET", delta: -45, isPositive: false },
                right: { text: "IMPERIAL CAPE", delta: 60, isPositive: true }
            },
            {
                z: 360,
                isMoving: true,
                moveSpeed: 4.0,
                moveAmp: 1.2,
                left: { text: "QUEEN DESTINY", delta: 65, isPositive: true },
                right: { text: "SHAME WALK", delta: -50, isPositive: false }
            },
            {
                z: 395,
                left: { text: "DARK CLOUD", delta: -55, isPositive: false },
                right: { text: "GOLDEN CORONET", delta: 70, isPositive: true }
            },
            {
                z: 425,
                left: { text: "IMPERIAL THRONE", delta: 80, isPositive: true },
                right: { text: "FAILURE", delta: -60, isPositive: false }
            }
        ],
        coins: [
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 14, count: 7 },
            { type: "arc", startX: 1.6, endX: -1.6, startZ: 48, count: 7 },
            { type: "line", x: 1.6, startZ: 84, count: 6 },
            { type: "arc", startX: 1.6, endX: -1.6, startZ: 120, count: 7 },
            { type: "line", x: -1.6, startZ: 155, count: 6 },
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 192, count: 8 },
            { type: "line", x: 1.6, startZ: 230, count: 6 },
            { type: "arc", startX: 1.6, endX: -1.6, startZ: 266, count: 7 },
            { type: "line", x: -1.6, startZ: 304, count: 6 },
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 340, count: 8 },
            { type: "line", x: 0, startZ: 378, count: 7 },
            { type: "arc", startX: -1.6, endX: 1.6, startZ: 408, count: 6 }
        ],
        gems: [
            { x: 0, z: 22, type: "ruby" },
            { x: -1.6, z: 88, type: "cyan" },
            { x: 1.6, z: 160, type: "ruby" },
            { x: -1.6, z: 235, type: "cyan" },
            { x: 1.6, z: 310, type: "ruby" },
            { x: 0, z: 380, type: "ruby" }
        ],
        hazards: [
            { x: 1.6, z: 52 },
            { x: -1.6, z: 110 },
            { x: 0, z: 146 },
            { x: 1.6, z: 182 },
            { x: -1.6, z: 220 },
            { x: 0, z: 258 },
            { x: 1.6, z: 295 },
            { x: -1.6, z: 330 },
            { x: 0, z: 370 }
        ]
    }
];

window.GAME_LEVELS = GAME_LEVELS;
