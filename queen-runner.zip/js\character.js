/**
 * 3D Queen Runner Character Engine for Babylon.js
 * Procedurally models a stylized fashion runner with hierarchical skeleton,
 * catwalk animations, 5 progressive outfit tiers, dynamic crown, and royal cape.
 */

class QueenCharacter {
    constructor(scene) {
        this.scene = scene;
        this.root = new BABYLON.TransformNode("queenRoot", scene);
        this.tier = 1; // 1 to 5
        this.animTime = 0;
        this.isCelebrating = false;
        this.celebrationTime = 0;
        this.stumbleTime = 0;
        this.spinTime = 0;
        this.tiltZ = 0;

        // References to body parts and clothing meshes
        this.parts = {};
        this.materials = {};
        this.particleSystem = null;

        this.initMaterials();
        this.buildRig();
        this.initParticles();
        this.applyTier(1, false);
    }

    initMaterials() {
        const createMat = (name, diffuseHex, emissiveHex = "#000000", specularHex = "#333333") => {
            const mat = new BABYLON.StandardMaterial(name, this.scene);
            mat.diffuseColor = BABYLON.Color3.FromHexString(diffuseHex);
            mat.emissiveColor = BABYLON.Color3.FromHexString(emissiveHex);
            mat.specularColor = BABYLON.Color3.FromHexString(specularHex);
            mat.specularPower = 32;
            return mat;
        };

        this.materials.skin = createMat("matSkin", "#ffdfc4", "#15100d", "#222222");
        this.materials.hairBrunette = createMat("matHairBrunette", "#3d2314", "#0a0503");
        this.materials.hairBlonde = createMat("matHairBlonde", "#ffd166", "#20180a", "#887755");
        this.materials.hairPlatinum = createMat("matHairPlat", "#f7f0fa", "#2a2233", "#ffffff");

        // Tier 1: Casual Messy Gray/Denim
        this.materials.tier1Top = createMat("matT1Top", "#888c94");
        this.materials.tier1Bottom = createMat("matT1Bottom", "#5c6b73");
        this.materials.tier1Shoes = createMat("matT1Shoes", "#d8dbe2");

        // Tier 2: Street Chic Pastel Mint & Lilac
        this.materials.tier2Top = createMat("matT2Top", "#ff70a6", "#220011");
        this.materials.tier2Bottom = createMat("matT2Bottom", "#70d6ff");
        this.materials.tier2Shoes = createMat("matT2Shoes", "#333333");

        // Tier 3: Gala Red Carpet Shimmer Magenta & Gold
        this.materials.tier3Dress = createMat("matT3Dress", "#e01a4f", "#330015", "#ffb703");
        this.materials.tier3Heels = createMat("matT3Heels", "#e01a4f", "#110005", "#ffffff");
        this.materials.goldTrim = createMat("matGoldTrim", "#ffb703", "#442a00", "#ffffff");

        // Tier 4: Royal Princess Emerald & Diamond
        this.materials.tier4Dress = createMat("matT4Dress", "#06d6a0", "#023525", "#ffffff");
        this.materials.tier4Heels = createMat("matT4Heels", "#ffd166", "#332200", "#ffffff");
        this.materials.tiara = createMat("matTiara", "#ffd700", "#553a00", "#ffffff");

        // Tier 5: Imperial Majestic Queen Gold & Royal Purple
        this.materials.tier5Gown = createMat("matT5Gown", "#ffd700", "#664d00", "#ffffff");
        this.materials.tier5Cape = createMat("matT5Cape", "#7209b7", "#220038", "#ffffff");
        this.materials.imperialCrown = createMat("matCrown", "#ffd700", "#775500", "#ffffff");
        this.materials.rubyGem = createMat("matRuby", "#ef233c", "#660011", "#ffffff");
    }

    buildRig() {
        const scene = this.scene;

        // Base Pelvis
        const pelvis = BABYLON.MeshBuilder.CreateBox("pelvis", { width: 0.38, height: 0.22, depth: 0.26 }, scene);
        pelvis.parent = this.root;
        pelvis.position.y = 1.05;
        this.parts.pelvis = pelvis;

        // Torso / Waist / Chest
        const waist = BABYLON.MeshBuilder.CreateCylinder("waist", { height: 0.26, diameterTop: 0.32, diameterBottom: 0.36 }, scene);
        waist.parent = pelvis;
        waist.position.y = 0.22;
        this.parts.waist = waist;

        const chest = BABYLON.MeshBuilder.CreateCylinder("chest", { height: 0.28, diameterTop: 0.38, diameterBottom: 0.30 }, scene);
        chest.parent = waist;
        chest.position.y = 0.25;
        this.parts.chest = chest;

        // Neck & Head
        const neck = BABYLON.MeshBuilder.CreateCylinder("neck", { height: 0.12, diameter: 0.14 }, scene);
        neck.parent = chest;
        neck.position.y = 0.20;
        neck.material = this.materials.skin;
        this.parts.neck = neck;

        const head = BABYLON.MeshBuilder.CreateSphere("head", { diameterX: 0.32, diameterY: 0.36, diameterZ: 0.32 }, scene);
        head.parent = neck;
        head.position.y = 0.22;
        head.material = this.materials.skin;
        this.parts.head = head;

        // Face details (Cute stylized eyes)
        const eyeMat = new BABYLON.StandardMaterial("matEyes", scene);
        eyeMat.diffuseColor = new BABYLON.Color3(0.1, 0.1, 0.15);
        const eyeL = BABYLON.MeshBuilder.CreateSphere("eyeL", { diameter: 0.06 }, scene);
        eyeL.parent = head;
        eyeL.position = new BABYLON.Vector3(-0.08, 0.03, 0.14);
        eyeL.material = eyeMat;

        const eyeR = eyeL.clone("eyeR");
        eyeR.parent = head;
        eyeR.position = new BABYLON.Vector3(0.08, 0.03, 0.14);

        // Lips
        const lipMat = new BABYLON.StandardMaterial("matLips", scene);
        lipMat.diffuseColor = BABYLON.Color3.FromHexString("#ef476f");
        const lips = BABYLON.MeshBuilder.CreateBox("lips", { width: 0.09, height: 0.03, depth: 0.04 }, scene);
        lips.parent = head;
        lips.position = new BABYLON.Vector3(0, -0.08, 0.15);
        lips.material = lipMat;

        // Hair Meshes
        // 1. Messy Hair (Tier 1)
        const hairMessy = BABYLON.MeshBuilder.CreateSphere("hairMessy", { diameterX: 0.36, diameterY: 0.38, diameterZ: 0.38 }, scene);
        hairMessy.parent = head;
        hairMessy.position = new BABYLON.Vector3(0, 0.04, -0.04);
        hairMessy.material = this.materials.hairBrunette;
        const messyPonytail = BABYLON.MeshBuilder.CreateSphere("messyPonytail", { diameter: 0.16 }, scene);
        messyPonytail.parent = hairMessy;
        messyPonytail.position = new BABYLON.Vector3(0, -0.1, -0.22);
        messyPonytail.material = this.materials.hairBrunette;
        this.parts.hairMessy = hairMessy;

        // 2. Chic Sleek Hair (Tier 2 & 3)
        const hairChic = BABYLON.MeshBuilder.CreateSphere("hairChic", { diameterX: 0.38, diameterY: 0.40, diameterZ: 0.38 }, scene);
        hairChic.parent = head;
        hairChic.position = new BABYLON.Vector3(0, 0.06, -0.02);
        hairChic.material = this.materials.hairBlonde;
        const chicBangs = BABYLON.MeshBuilder.CreateBox("chicBangs", { width: 0.32, height: 0.12, depth: 0.1 }, scene);
        chicBangs.parent = hairChic;
        chicBangs.position = new BABYLON.Vector3(0, 0.12, 0.12);
        chicBangs.rotation.x = 0.3;
        chicBangs.material = this.materials.hairBlonde;
        this.parts.hairChic = hairChic;

        // 3. Royal Flowing Locks (Tier 4 & 5)
        const hairRoyal = BABYLON.MeshBuilder.CreateSphere("hairRoyal", { diameterX: 0.42, diameterY: 0.44, diameterZ: 0.40 }, scene);
        hairRoyal.parent = head;
        hairRoyal.position = new BABYLON.Vector3(0, 0.08, -0.02);
        hairRoyal.material = this.materials.hairPlatinum;
        // Cascading back locks
        const royalLocks = BABYLON.MeshBuilder.CreateCylinder("royalLocks", { height: 0.65, diameterTop: 0.32, diameterBottom: 0.45 }, scene);
        royalLocks.parent = hairRoyal;
        royalLocks.position = new BABYLON.Vector3(0, -0.3, -0.15);
        royalLocks.rotation.x = -0.25;
        royalLocks.material = this.materials.hairPlatinum;
        this.parts.hairRoyal = hairRoyal;

        // Crowns / Tiaras
        // Princess Tiara (Tier 4)
        const tiara = BABYLON.MeshBuilder.CreateTorus("tiara", { diameter: 0.28, thickness: 0.04, tessellation: 24 }, scene);
        tiara.parent = head;
        tiara.position = new BABYLON.Vector3(0, 0.22, 0.02);
        tiara.material = this.materials.tiara;
        this.parts.tiara = tiara;

        // Grand Imperial Queen Crown (Tier 5)
        const crownBase = BABYLON.MeshBuilder.CreateCylinder("crownBase", { height: 0.12, diameter: 0.34 }, scene);
        crownBase.parent = head;
        crownBase.position = new BABYLON.Vector3(0, 0.25, 0.02);
        crownBase.material = this.materials.imperialCrown;

        // Crown Spikes with jewels
        for (let i = 0; i < 5; i++) {
            const angle = (i / 5) * Math.PI * 2;
            const spike = BABYLON.MeshBuilder.CreateCylinder("spike_" + i, { height: 0.18, diameterTop: 0.02, diameterBottom: 0.07 }, scene);
            spike.parent = crownBase;
            spike.position = new BABYLON.Vector3(Math.cos(angle) * 0.15, 0.12, Math.sin(angle) * 0.15);
            spike.material = this.materials.imperialCrown;

            const jewel = BABYLON.MeshBuilder.CreateSphere("jewel_" + i, { diameter: 0.06 }, scene);
            jewel.parent = spike;
            jewel.position.y = 0.09;
            jewel.material = this.materials.rubyGem;
        }
        this.parts.crown = crownBase;

        // Flowing Skirts / Gowns
        // Casual / Tier 1 Pants
        const pantsL = BABYLON.MeshBuilder.CreateCylinder("pantsL", { height: 0.48, diameter: 0.17 }, scene);
        const pantsR = BABYLON.MeshBuilder.CreateCylinder("pantsR", { height: 0.48, diameter: 0.17 }, scene);
        this.parts.pantsL = pantsL;
        this.parts.pantsR = pantsR;

        // Tier 2 Mini Skirt
        const miniSkirt = BABYLON.MeshBuilder.CreateCylinder("miniSkirt", { height: 0.28, diameterTop: 0.38, diameterBottom: 0.50 }, scene);
        miniSkirt.parent = pelvis;
        miniSkirt.position.y = -0.12;
        miniSkirt.material = this.materials.tier2Bottom;
        this.parts.miniSkirt = miniSkirt;

        // Tier 3 Cocktail Dress Skirt
        const cocktailSkirt = BABYLON.MeshBuilder.CreateCylinder("cocktailSkirt", { height: 0.48, diameterTop: 0.38, diameterBottom: 0.65 }, scene);
        cocktailSkirt.parent = pelvis;
        cocktailSkirt.position.y = -0.22;
        cocktailSkirt.material = this.materials.tier3Dress;
        this.parts.cocktailSkirt = cocktailSkirt;

        // Tier 4 Princess Ballgown Skirt
        const princessBallgown = BABYLON.MeshBuilder.CreateCylinder("ballgown", { height: 0.72, diameterTop: 0.40, diameterBottom: 0.95 }, scene);
        princessBallgown.parent = pelvis;
        princessBallgown.position.y = -0.35;
        princessBallgown.material = this.materials.tier4Dress;
        this.parts.princessBallgown = princessBallgown;

        // Tier 5 Majestic Imperial Gown
        const imperialGown = BABYLON.MeshBuilder.CreateCylinder("imperialGown", { height: 0.85, diameterTop: 0.42, diameterBottom: 1.15 }, scene);
        imperialGown.parent = pelvis;
        imperialGown.position.y = -0.42;
        imperialGown.material = this.materials.tier5Gown;
        this.parts.imperialGown = imperialGown;

        // Royal Velvet Cape / Train (Tier 5)
        const cape = BABYLON.MeshBuilder.CreateBox("royalCape", { width: 0.65, height: 1.1, depth: 0.05 }, scene);
        cape.parent = chest;
        cape.position = new BABYLON.Vector3(0, -0.3, -0.24);
        cape.rotation.x = 0.2;
        cape.material = this.materials.tier5Cape;
        this.parts.cape = cape;

        // ARMS RIG
        const buildArm = (isLeft) => {
            const side = isLeft ? -1 : 1;
            const shoulder = new BABYLON.TransformNode("shoulder_" + (isLeft ? "L" : "R"), scene);
            shoulder.parent = chest;
            shoulder.position = new BABYLON.Vector3(side * 0.24, 0.08, 0);

            const upperArm = BABYLON.MeshBuilder.CreateCylinder("upperArm_" + (isLeft ? "L" : "R"), { height: 0.32, diameter: 0.11 }, scene);
            upperArm.parent = shoulder;
            upperArm.position.y = -0.16;
            upperArm.material = this.materials.skin;

            const elbow = new BABYLON.TransformNode("elbow_" + (isLeft ? "L" : "R"), scene);
            elbow.parent = upperArm;
            elbow.position.y = -0.16;

            const forearm = BABYLON.MeshBuilder.CreateCylinder("forearm_" + (isLeft ? "L" : "R"), { height: 0.30, diameter: 0.09 }, scene);
            forearm.parent = elbow;
            forearm.position.y = -0.15;
            forearm.material = this.materials.skin;

            const hand = BABYLON.MeshBuilder.CreateSphere("hand_" + (isLeft ? "L" : "R"), { diameter: 0.10 }, scene);
            hand.parent = forearm;
            hand.position.y = -0.16;
            hand.material = this.materials.skin;

            return { shoulder, upperArm, elbow, forearm, hand };
        };

        this.parts.armL = buildArm(true);
        this.parts.armR = buildArm(false);

        // LEGS RIG
        const buildLeg = (isLeft) => {
            const side = isLeft ? -1 : 1;
            const hip = new BABYLON.TransformNode("hip_" + (isLeft ? "L" : "R"), scene);
            hip.parent = pelvis;
            hip.position = new BABYLON.Vector3(side * 0.12, -0.1, 0);

            const upperLeg = BABYLON.MeshBuilder.CreateCylinder("upperLeg_" + (isLeft ? "L" : "R"), { height: 0.46, diameter: 0.14 }, scene);
            upperLeg.parent = hip;
            upperLeg.position.y = -0.23;
            upperLeg.material = this.materials.skin;

            const knee = new BABYLON.TransformNode("knee_" + (isLeft ? "L" : "R"), scene);
            knee.parent = upperLeg;
            knee.position.y = -0.23;

            const lowerLeg = BABYLON.MeshBuilder.CreateCylinder("lowerLeg_" + (isLeft ? "L" : "R"), { height: 0.44, diameter: 0.11 }, scene);
            lowerLeg.parent = knee;
            lowerLeg.position.y = -0.22;
            lowerLeg.material = this.materials.skin;

            // Shoes / Heels
            const shoe = BABYLON.MeshBuilder.CreateBox("shoe_" + (isLeft ? "L" : "R"), { width: 0.11, height: 0.12, depth: 0.22 }, scene);
            shoe.parent = lowerLeg;
            shoe.position = new BABYLON.Vector3(0, -0.22, 0.04);
            shoe.material = this.materials.tier1Shoes;

            // High Heel Spike
            const stiletto = BABYLON.MeshBuilder.CreateCylinder("stiletto_" + (isLeft ? "L" : "R"), { height: 0.12, diameterTop: 0.04, diameterBottom: 0.02 }, scene);
            stiletto.parent = shoe;
            stiletto.position = new BABYLON.Vector3(0, -0.06, -0.06);
            stiletto.material = this.materials.goldTrim;

            return { hip, upperLeg, knee, lowerLeg, shoe, stiletto };
        };

        this.parts.legL = buildLeg(true);
        this.parts.legR = buildLeg(false);

        // Attach casual pants meshes to upper legs
        pantsL.parent = this.parts.legL.hip;
        pantsL.position.y = -0.23;
        pantsL.material = this.materials.tier1Bottom;

        pantsR.parent = this.parts.legR.hip;
        pantsR.position.y = -0.23;
        pantsR.material = this.materials.tier1Bottom;
    }

    initParticles() {
        const scene = this.scene;
        // Golden sparkle trail / aura
        this.particleSystem = new BABYLON.ParticleSystem("queenSparkles", 120, scene);
        this.particleSystem.particleTexture = new BABYLON.Texture("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAbUlEQVRYR+2WwQkAMQzDRHfQ/We0K4R+d1AQW1yR9E3B4y8L4M3rI0GIAI4hFwDkO4f1mCNAAARAAARAAARAAARAwH8JkO3jI0GIAI4hFwDkO4f1mCNAAARAAARAAARAAARAwF8T+ADqK2e1W8o1wQAAAABJRU5ErkJggg==", scene);

        this.particleSystem.emitter = this.root;
        this.particleSystem.minEmitBox = new BABYLON.Vector3(-0.3, 0.4, -0.2);
        this.particleSystem.maxEmitBox = new BABYLON.Vector3(0.3, 1.8, 0.2);

        this.particleSystem.color1 = new BABYLON.Color4(1.0, 0.85, 0.2, 1.0);
        this.particleSystem.color2 = new BABYLON.Color4(1.0, 0.4, 0.8, 0.8);
        this.particleSystem.colorDead = new BABYLON.Color4(1.0, 1.0, 1.0, 0.0);

        this.particleSystem.minSize = 0.08;
        this.particleSystem.maxSize = 0.22;
        this.particleSystem.minLifeTime = 0.4;
        this.particleSystem.maxLifeTime = 0.8;
        this.particleSystem.emitRate = 40;

        this.particleSystem.gravity = new BABYLON.Vector3(0, 1.2, 0);
        this.particleSystem.direction1 = new BABYLON.Vector3(-0.2, 0.8, -0.5);
        this.particleSystem.direction2 = new BABYLON.Vector3(0.2, 1.2, -0.8);
        this.particleSystem.minEmitPower = 0.5;
        this.particleSystem.maxEmitPower = 1.2;
    }

    applyTier(tier, triggerEffect = true) {
        this.tier = Math.max(1, Math.min(5, tier));

        // Hide all outfit variants first
        this.parts.hairMessy.setEnabled(false);
        this.parts.hairChic.setEnabled(false);
        this.parts.hairRoyal.setEnabled(false);

        this.parts.tiara.setEnabled(false);
        this.parts.crown.setEnabled(false);
        this.parts.cape.setEnabled(false);

        this.parts.pantsL.setEnabled(false);
        this.parts.pantsR.setEnabled(false);
        this.parts.miniSkirt.setEnabled(false);
        this.parts.cocktailSkirt.setEnabled(false);
        this.parts.princessBallgown.setEnabled(false);
        this.parts.imperialGown.setEnabled(false);

        this.parts.legL.stiletto.setEnabled(false);
        this.parts.legR.stiletto.setEnabled(false);

        if (this.tier === 1) {
            // Tier 1: Casual / Slouch
            this.parts.hairMessy.setEnabled(true);
            this.parts.pantsL.setEnabled(true);
            this.parts.pantsR.setEnabled(true);
            this.parts.waist.material = this.materials.tier1Top;
            this.parts.chest.material = this.materials.tier1Top;
            this.parts.legL.shoe.material = this.materials.tier1Shoes;
            this.parts.legR.shoe.material = this.materials.tier1Shoes;
            this.particleSystem.stop();
        } else if (this.tier === 2) {
            // Tier 2: Street Chic
            this.parts.hairChic.setEnabled(true);
            this.parts.miniSkirt.setEnabled(true);
            this.parts.waist.material = this.materials.tier2Top;
            this.parts.chest.material = this.materials.tier2Top;
            this.parts.legL.shoe.material = this.materials.tier2Shoes;
            this.parts.legR.shoe.material = this.materials.tier2Shoes;
            this.particleSystem.stop();
        } else if (this.tier === 3) {
            // Tier 3: Gala Red Carpet
            this.parts.hairChic.setEnabled(true);
            this.parts.cocktailSkirt.setEnabled(true);
            this.parts.waist.material = this.materials.tier3Dress;
            this.parts.chest.material = this.materials.tier3Dress;
            this.parts.legL.shoe.material = this.materials.tier3Heels;
            this.parts.legR.shoe.material = this.materials.tier3Heels;
            this.parts.legL.stiletto.setEnabled(true);
            this.parts.legR.stiletto.setEnabled(true);
            this.particleSystem.emitRate = 25;
            this.particleSystem.start();
        } else if (this.tier === 4) {
            // Tier 4: Royal Princess
            this.parts.hairRoyal.setEnabled(true);
            this.parts.tiara.setEnabled(true);
            this.parts.princessBallgown.setEnabled(true);
            this.parts.waist.material = this.materials.tier4Dress;
            this.parts.chest.material = this.materials.tier4Dress;
            this.parts.legL.shoe.material = this.materials.tier4Heels;
            this.parts.legR.shoe.material = this.materials.tier4Heels;
            this.parts.legL.stiletto.setEnabled(true);
            this.parts.legR.stiletto.setEnabled(true);
            this.particleSystem.emitRate = 50;
            this.particleSystem.start();
        } else if (this.tier === 5) {
            // Tier 5: Majestic Imperial Queen
            this.parts.hairRoyal.setEnabled(true);
            this.parts.crown.setEnabled(true);
            this.parts.cape.setEnabled(true);
            this.parts.imperialGown.setEnabled(true);
            this.parts.waist.material = this.materials.tier5Gown;
            this.parts.chest.material = this.materials.tier5Gown;
            this.parts.legL.shoe.material = this.materials.tier5Gown;
            this.parts.legR.shoe.material = this.materials.tier5Gown;
            this.parts.legL.stiletto.setEnabled(true);
            this.parts.legR.stiletto.setEnabled(true);
            this.particleSystem.emitRate = 90;
            this.particleSystem.start();
        }

        if (triggerEffect) {
            this.spinTime = 0.65; // Quick celebratory runway pirouette!
            if (window.gameAudio) window.gameAudio.playLevelUp();
        }
    }

    triggerStumble() {
        this.stumbleTime = 0.55;
    }

    triggerCelebration() {
        this.isCelebrating = true;
        this.celebrationTime = 0;
        this.particleSystem.emitRate = 120;
        this.particleSystem.start();
    }

    update(deltaTime, runSpeed, isRunning, steeringVelocity = 0) {
        const p = this.parts;

        // Smooth banking tilt into turns
        const targetTilt = -steeringVelocity * 0.28;
        this.tiltZ += (targetTilt - this.tiltZ) * Math.min(1.0, deltaTime * 12);
        this.root.rotation.z = this.tiltZ;

        // Pirouette Spin animation when changing tiers
        if (this.spinTime > 0) {
            this.spinTime -= deltaTime;
            const spinProgress = 1 - (this.spinTime / 0.65);
            this.root.rotation.y = spinProgress * Math.PI * 2;
            if (this.spinTime <= 0) {
                this.root.rotation.y = 0;
            }
        }

        // Grand Coronation Celebration Walk / Pose
        if (this.isCelebrating) {
            this.celebrationTime += deltaTime;
            const t = this.celebrationTime;

            // Royal wave and poise
            p.pelvis.position.y = 1.05 + Math.sin(t * 2) * 0.02;
            p.pelvis.rotation.z = 0;
            p.pelvis.rotation.y = Math.sin(t * 1.5) * 0.15;

            // Crown levitation / glow pulsing
            if (p.crown.isEnabled()) {
                p.crown.rotation.y += deltaTime * 1.5;
                p.crown.position.y = 0.25 + Math.abs(Math.sin(t * 3)) * 0.04;
            }

            // Right Arm: Elegant Royal Wave to Kingdom
            p.armR.shoulder.rotation.x = -1.2;
            p.armR.shoulder.rotation.z = 0.7 + Math.sin(t * 4) * 0.35;
            p.armR.elbow.rotation.x = -0.5;

            // Left Arm: Regal hand-on-hip pose
            p.armL.shoulder.rotation.x = 0.2;
            p.armL.shoulder.rotation.z = -0.6;
            p.armL.elbow.rotation.x = 0.8;

            // Legs static poised
            p.legL.hip.rotation.x = 0.05;
            p.legR.hip.rotation.x = -0.05;
            p.legL.knee.rotation.x = 0;
            p.legR.knee.rotation.x = 0;
            return;
        }

        // Stumble Reaction
        if (this.stumbleTime > 0) {
            this.stumbleTime -= deltaTime;
            const st = this.stumbleTime / 0.55;
            p.pelvis.rotation.x = (1 - st) * 0.35; // Lean forward stumble
            p.armL.shoulder.rotation.x = -0.8;
            p.armR.shoulder.rotation.x = -0.8;
            p.armL.shoulder.rotation.z = -0.8;
            p.armR.shoulder.rotation.z = 0.8;
            return;
        } else {
            p.pelvis.rotation.x = 0;
        }

        // RUNNING CATWALK ANIMATION
        if (isRunning && runSpeed > 0) {
            const cadence = Math.min(18, Math.max(9, runSpeed * 0.85));
            this.animTime += deltaTime * cadence;
            const a = this.animTime;

            // Catwalk Hip Sway (sensual, confident runway swagger)
            const hipSwayAmount = this.tier >= 3 ? 0.22 : 0.14;
            p.pelvis.rotation.z = Math.sin(a) * hipSwayAmount;
            p.pelvis.rotation.y = Math.cos(a) * (hipSwayAmount * 0.7);

            // Vertical bounce
            p.pelvis.position.y = 1.05 + Math.abs(Math.sin(a * 2)) * 0.06;

            // Torso counter-sway
            p.chest.rotation.z = -p.pelvis.rotation.z * 0.5;
            p.chest.rotation.y = -p.pelvis.rotation.y * 0.6;

            // Head poise
            p.head.rotation.z = -p.pelvis.rotation.z * 0.3;
            p.head.rotation.x = -0.05 + Math.sin(a * 2) * 0.03;

            // LEGS ANIMATION
            const legAmp = 0.75;
            p.legL.hip.rotation.x = Math.sin(a) * legAmp;
            p.legR.hip.rotation.x = -Math.sin(a) * legAmp;

            // Knee flex on backswing
            p.legL.knee.rotation.x = Math.max(0, -Math.sin(a)) * 0.95;
            p.legR.knee.rotation.x = Math.max(0, Math.sin(a)) * 0.95;

            // Heel sound sync
            if (Math.abs(Math.sin(a)) < 0.1 && window.gameAudio) {
                window.gameAudio.playHeelClick();
            }

            // ARMS ANIMATION (Graceful high-fashion arm pump)
            const armAmp = 0.52;
            p.armL.shoulder.rotation.x = -Math.sin(a) * armAmp;
            p.armR.shoulder.rotation.x = Math.sin(a) * armAmp;

            // Poised chic arm stance (elbows tucked, hands slightly outwards)
            p.armL.shoulder.rotation.z = -0.25;
            p.armR.shoulder.rotation.z = 0.25;
            p.armL.elbow.rotation.x = 0.35 + Math.abs(Math.sin(a)) * 0.2;
            p.armR.elbow.rotation.x = 0.35 + Math.abs(Math.cos(a)) * 0.2;

            // Flowing cape wave
            if (p.cape.isEnabled()) {
                p.cape.rotation.x = 0.35 + (runSpeed / 20) * 0.45 + Math.sin(a * 2) * 0.1;
                p.cape.rotation.y = Math.sin(a) * 0.1;
            }
        } else {
            // Idle stance
            p.pelvis.rotation.z = 0.08;
            p.pelvis.rotation.y = -0.05;
            p.legL.hip.rotation.x = 0;
            p.legR.hip.rotation.x = 0;
            p.legL.knee.rotation.x = 0;
            p.legR.knee.rotation.x = 0;
            p.armL.shoulder.rotation.x = 0.1;
            p.armR.shoulder.rotation.x = -0.1;
            p.armL.elbow.rotation.x = 0.2;
            p.armR.elbow.rotation.x = 0.2;
        }
    }
}

window.QueenCharacter = QueenCharacter;
