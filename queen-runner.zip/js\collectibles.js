/**
 * 3D Collectibles & Obstacles Manager for Queen Runner 3D
 * Handles spinning golden coins, royal diamonds/gems, mud hazards, magnetism suction,
 * and collection particle bursts.
 */

class CollectiblesManager {
    constructor(scene) {
        this.scene = scene;
        this.root = new BABYLON.TransformNode("collectiblesRoot", scene);
        this.items = []; // coins and gems
        this.hazards = []; // mud puddles
        this.materials = {};
        this.initMaterials();
    }

    initMaterials() {
        const scene = this.scene;
        const createMat = (name, hex, emissiveHex = "#000000") => {
            const mat = new BABYLON.StandardMaterial(name, scene);
            mat.diffuseColor = BABYLON.Color3.FromHexString(hex);
            mat.emissiveColor = BABYLON.Color3.FromHexString(emissiveHex);
            mat.specularColor = new BABYLON.Color3(1, 1, 1);
            mat.specularPower = 64;
            return mat;
        };

        this.materials.coinGold = createMat("matCoinGold", "#ffb703", "#664400");
        this.materials.gemRuby = createMat("matGemRuby", "#ef233c", "#440011");
        this.materials.gemCyan = createMat("matGemCyan", "#00f5d4", "#00332a");
        this.materials.mud = createMat("matMud", "#3d2314", "#150a04");
    }

    clear() {
        const children = this.root.getChildMeshes();
        for (let i = children.length - 1; i >= 0; i--) {
            children[i].dispose();
        }
        this.items = [];
        this.hazards = [];
    }

    spawnCoin(x, z, value = 1) {
        const scene = this.scene;
        const coin = BABYLON.MeshBuilder.CreateCylinder("coin", {
            height: 0.08,
            diameter: 0.55,
            tessellation: 16
        }, scene);
        coin.parent = this.root;
        coin.rotation.x = Math.PI / 2; // Face forward
        coin.position = new BABYLON.Vector3(x, 0.7, z);
        coin.material = this.materials.coinGold;

        // Inner coin ring detail
        const star = BABYLON.MeshBuilder.CreateSphere("coinCenter", { diameter: 0.25 }, scene);
        star.parent = coin;
        star.position.y = 0.04;
        star.material = this.materials.coinGold;

        this.items.push({
            type: "coin",
            mesh: coin,
            baseY: 0.7,
            value: value,
            active: true,
            rotSpeed: 3.5,
            phase: Math.random() * Math.PI
        });
    }

    spawnCoinLine(x, startZ, count, spacing = 2.5) {
        for (let i = 0; i < count; i++) {
            this.spawnCoin(x, startZ + i * spacing);
        }
    }

    spawnCoinArc(startX, endX, startZ, count) {
        const spanZ = count * 2.2;
        for (let i = 0; i < count; i++) {
            const t = i / (count - 1);
            const x = startX + (endX - startX) * t;
            const z = startZ + i * 2.2;
            this.spawnCoin(x, z);
        }
    }

    spawnGem(x, z, gemType = "ruby") {
        const scene = this.scene;
        const gem = BABYLON.MeshBuilder.CreatePolyhedron("gem", {
            type: 1, // Octahedron
            size: 0.45
        }, scene);
        gem.parent = this.root;
        gem.position = new BABYLON.Vector3(x, 0.85, z);
        gem.material = gemType === "ruby" ? this.materials.gemRuby : this.materials.gemCyan;

        this.items.push({
            type: "gem",
            mesh: gem,
            baseY: 0.85,
            value: 5,
            glamourBonus: 8,
            active: true,
            rotSpeed: 4.2,
            phase: Math.random() * Math.PI
        });
    }

    spawnMudHazard(x, z) {
        const scene = this.scene;
        const puddle = BABYLON.MeshBuilder.CreateDisc("mudPuddle", {
            radius: 0.9,
            tessellation: 16
        }, scene);
        puddle.parent = this.root;
        puddle.rotation.x = Math.PI / 2;
        puddle.position = new BABYLON.Vector3(x, 0.02, z);
        puddle.material = this.materials.mud;

        this.hazards.push({
            mesh: puddle,
            x: x,
            z: z,
            radius: 0.85,
            active: true
        });
    }

    update(deltaTime, playerPos, onCollect, onHazard) {
        const time = performance.now() * 0.001;

        // 1. Update Coins & Gems
        for (let i = 0; i < this.items.length; i++) {
            const item = this.items[i];
            if (!item.active) continue;

            // Rotation and floating bob
            item.mesh.rotation.y += deltaTime * item.rotSpeed;
            item.mesh.position.y = item.baseY + Math.sin(time * 3 + item.phase) * 0.12;

            // Distance to player
            const dx = playerPos.x - item.mesh.position.x;
            const dy = (playerPos.y + 0.8) - item.mesh.position.y;
            const dz = playerPos.z - item.mesh.position.z;
            const distSq = dx * dx + dz * dz;

            // Magnetism suction when close
            if (distSq < 7.0 && dz < 0) {
                // Accelerate coin towards queen
                item.mesh.position.x += dx * deltaTime * 8.0;
                item.mesh.position.z += dz * deltaTime * 8.0;
                item.mesh.position.y += dy * deltaTime * 8.0;
            }

            // Collection collision check (radius 0.9)
            if (distSq < 0.85 && Math.abs(dz) < 1.0) {
                item.active = false;
                item.mesh.dispose();
                onCollect(item);
            }
        }

        // 2. Update Hazards (Mud Puddles)
        for (let i = 0; i < this.hazards.length; i++) {
            const h = this.hazards[i];
            if (!h.active) continue;

            const dx = playerPos.x - h.x;
            const dz = playerPos.z - h.z;
            const distSq = dx * dx + dz * dz;

            if (distSq < h.radius * h.radius && Math.abs(dz) < 0.6) {
                h.active = false;
                // Discolor or splatter puddle
                h.mesh.scaling.setAll(0.8);
                onHazard(h);
            }
        }
    }
}

window.CollectiblesManager = CollectiblesManager;
