/**
 * Procedural Audio Engine for Queen Runner 3D
 * Synthesizes all game sound effects and background catwalk music using Web Audio API.
 * Requires zero external audio files.
 */
class SoundEngine {
    constructor() {
        this.ctx = null;
        this.isMuted = false;
        this.musicPlaying = false;
        this.bgmTimer = null;
        this.bgmStep = 0;
        this.tempo = 124; // Fashion catwalk BPM
        this.masterGain = null;
        this.sfxGain = null;
        this.bgmGain = null;
    }

    init() {
        if (this.ctx) return;
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) return;
        this.ctx = new AudioCtx();

        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(1.0, this.ctx.currentTime);
        this.masterGain.connect(this.ctx.destination);

        this.sfxGain = this.ctx.createGain();
        this.sfxGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
        this.sfxGain.connect(this.masterGain);

        this.bgmGain = this.ctx.createGain();
        this.bgmGain.gain.setValueAtTime(0.35, this.ctx.currentTime);
        this.bgmGain.connect(this.masterGain);
    }

    resume() {
        this.init();
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    toggleMute() {
        this.isMuted = !this.isMuted;
        if (this.masterGain && this.ctx) {
            this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 1.0, this.ctx.currentTime);
        }
        return this.isMuted;
    }

    // --- SFX ---

    playCoin() {
        if (!this.ctx || this.isMuted) return;
        this.resume();
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(987.77, t); // B5
        osc.frequency.exponentialRampToValueAtTime(1318.51, t + 0.08); // E6

        gain.gain.setValueAtTime(0.35, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(t);
        osc.stop(t + 0.25);
    }

    playGem() {
        if (!this.ctx || this.isMuted) return;
        this.resume();
        const t = this.ctx.currentTime;
        const notes = [1046.50, 1318.51, 1567.98, 2093.00]; // C6, E6, G6, C7 arpeggio
        notes.forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const start = t + idx * 0.04;

            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, start);

            gain.gain.setValueAtTime(0.3, start);
            gain.gain.exponentialRampToValueAtTime(0.001, start + 0.3);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(start);
            osc.stop(start + 0.3);
        });
    }

    playPositiveGate() {
        if (!this.ctx || this.isMuted) return;
        this.resume();
        const t = this.ctx.currentTime;
        // Bright radiant major triad with shimmer
        const freqs = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
        freqs.forEach((freq, idx) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const start = t + idx * 0.03;

            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, start);
            osc.frequency.linearRampToValueAtTime(freq * 1.05, start + 0.35);

            gain.gain.setValueAtTime(0.28, start);
            gain.gain.exponentialRampToValueAtTime(0.001, start + 0.45);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(start);
            osc.stop(start + 0.45);
        });
    }

    playNegativeGate() {
        if (!this.ctx || this.isMuted) return;
        this.resume();
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, t);
        osc.frequency.exponentialRampToValueAtTime(80, t + 0.3);

        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(600, t);
        filter.frequency.exponentialRampToValueAtTime(150, t + 0.3);

        gain.gain.setValueAtTime(0.35, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.3);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(t);
        osc.stop(t + 0.3);
    }

    playLevelUp() {
        if (!this.ctx || this.isMuted) return;
        this.resume();
        const t = this.ctx.currentTime;
        // Majestic triumphant ascending chords
        const notes = [440, 554.37, 659.25, 880, 1108.73, 1318.51];
        notes.forEach((f, i) => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const start = t + i * 0.05;

            osc.type = 'sine';
            osc.frequency.setValueAtTime(f, start);

            gain.gain.setValueAtTime(0.25, start);
            gain.gain.exponentialRampToValueAtTime(0.001, start + 0.5);

            osc.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(start);
            osc.stop(start + 0.5);
        });
    }

    playCoronationFanfare() {
        if (!this.ctx || this.isMuted) return;
        this.resume();
        const t = this.ctx.currentTime;
        // Royal Brass Coronation Fanfare: C4 -> G4 -> C5 -> E5 -> G5 -> C6 held
        const fanfare = [
            { f: 261.63, d: 0.15, offset: 0.0 },   // C4
            { f: 392.00, d: 0.15, offset: 0.15 },  // G4
            { f: 523.25, d: 0.15, offset: 0.30 },  // C5
            { f: 659.25, d: 0.20, offset: 0.45 },  // E5
            { f: 783.99, d: 0.25, offset: 0.65 },  // G5
            { f: 1046.50, d: 1.2, offset: 0.90 }   // High C6 sustained triumphant
        ];

        fanfare.forEach(item => {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            const filter = this.ctx.createBiquadFilter();
            const start = t + item.offset;

            osc.type = 'sawtooth'; // Brass timbre
            osc.frequency.setValueAtTime(item.f, start);

            filter.type = 'lowpass';
            filter.frequency.setValueAtTime(item.f * 3.5, start);

            gain.gain.setValueAtTime(0.0, start);
            gain.gain.linearRampToValueAtTime(0.3, start + 0.03);
            gain.gain.exponentialRampToValueAtTime(0.001, start + item.d);

            osc.connect(filter);
            filter.connect(gain);
            gain.connect(this.sfxGain);

            osc.start(start);
            osc.stop(start + item.d);
        });
    }

    playConfetti() {
        if (!this.ctx || this.isMuted) return;
        this.resume();
        const t = this.ctx.currentTime;
        // White noise pop
        const bufferSize = this.ctx.sampleRate * 0.2;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.25));
        }

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1200, t);

        const gain = this.ctx.createGain();
        gain.gain.setValueAtTime(0.4, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.2);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.sfxGain);

        noise.start(t);
    }

    playHeelClick() {
        if (!this.ctx || this.isMuted) return;
        const t = this.ctx.currentTime;
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(700, t);
        osc.frequency.exponentialRampToValueAtTime(200, t + 0.03);

        gain.gain.setValueAtTime(0.06, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.03);

        osc.connect(gain);
        gain.connect(this.sfxGain);

        osc.start(t);
        osc.stop(t + 0.03);
    }

    // --- PROCEDURAL BGM (Catwalk Runway Electronic Groove) ---

    startBGM() {
        if (this.musicPlaying) return;
        this.resume();
        this.musicPlaying = true;
        this.bgmStep = 0;

        const stepTime = (60 / this.tempo) / 4; // 16th notes
        const bassNotes = [
            110.00, 110.00, 0, 110.00, 130.81, 0, 146.83, 0,
            110.00, 110.00, 164.81, 0, 130.81, 146.83, 110.00, 0
        ]; // A minor funk groove

        const scheduleBeat = () => {
            if (!this.musicPlaying || !this.ctx) return;
            const t = this.ctx.currentTime;
            const step = this.bgmStep % 16;

            // 1. Four on the floor kick (every 4 16ths: 0, 4, 8, 12)
            if (step % 4 === 0) {
                const kickOsc = this.ctx.createOscillator();
                const kickGain = this.ctx.createGain();
                kickOsc.frequency.setValueAtTime(130, t);
                kickOsc.frequency.exponentialRampToValueAtTime(35, t + 0.09);
                kickGain.gain.setValueAtTime(0.26, t);
                kickGain.gain.exponentialRampToValueAtTime(0.001, t + 0.09);
                kickOsc.connect(kickGain);
                kickGain.connect(this.bgmGain);
                kickOsc.start(t);
                kickOsc.stop(t + 0.09);
            }

            // 2. Crisp Catwalk Hi-Hat on offbeats (2, 6, 10, 14)
            if (step % 4 === 2) {
                const hatOsc = this.ctx.createOscillator();
                const hatGain = this.ctx.createGain();
                hatOsc.type = 'highpass' in hatOsc ? 'sine' : 'square';
                hatOsc.frequency.setValueAtTime(8000 + Math.random() * 2000, t);
                hatGain.gain.setValueAtTime(0.08, t);
                hatGain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
                hatOsc.connect(hatGain);
                hatGain.connect(this.bgmGain);
                hatOsc.start(t);
                hatOsc.stop(t + 0.04);
            }

            // 3. Bassline
            const note = bassNotes[step];
            if (note > 0) {
                const bassOsc = this.ctx.createOscillator();
                const bassGain = this.ctx.createGain();
                bassOsc.type = 'sawtooth';
                bassOsc.frequency.setValueAtTime(note, t);

                const filter = this.ctx.createBiquadFilter();
                filter.type = 'lowpass';
                filter.frequency.setValueAtTime(450, t);

                bassGain.gain.setValueAtTime(0.14, t);
                bassGain.gain.exponentialRampToValueAtTime(0.001, t + stepTime * 0.9);

                bassOsc.connect(filter);
                filter.connect(bassGain);
                bassGain.connect(this.bgmGain);

                bassOsc.start(t);
                bassOsc.stop(t + stepTime * 0.9);
            }

            // 4. Synth chord stab on bars (step 0 and step 8)
            if (step === 0 || step === 8) {
                const chord = step === 0 ? [220, 261.63, 329.63] : [196, 246.94, 293.66];
                chord.forEach(freq => {
                    const chOsc = this.ctx.createOscillator();
                    const chGain = this.ctx.createGain();
                    chOsc.type = 'sine';
                    chOsc.frequency.setValueAtTime(freq * 2, t);
                    chGain.gain.setValueAtTime(0.09, t);
                    chGain.gain.exponentialRampToValueAtTime(0.001, t + 0.35);
                    chOsc.connect(chGain);
                    chGain.connect(this.bgmGain);
                    chOsc.start(t);
                    chOsc.stop(t + 0.35);
                });
            }

            this.bgmStep++;
            this.bgmTimer = setTimeout(scheduleBeat, stepTime * 1000);
        };

        scheduleBeat();
    }

    stopBGM() {
        this.musicPlaying = false;
        if (this.bgmTimer) {
            clearTimeout(this.bgmTimer);
            this.bgmTimer = null;
        }
    }
}

// Global sound singleton
window.gameAudio = new SoundEngine();
