/**
 * 3D Fashion Choice Gates for Queen Runner 3D
 * Generates glowing dual archways with dynamic text banners, icons, glamour point modifiers,
 * collision triggers, and animated movement.
 */

class ChoiceGateManager {
    constructor(scene) {
        this.scene = scene;
        this.gatePairs = [];
        this.root = new BABYLON.TransformNode("gatesRoot", scene);
        this.materials = {};
        this.initMaterials();
    }

    initMaterials() {
        const scene = this.scene;
        const createMat = (name, hex, emissiveHex = "#000000", alpha = 1.0) => {
            const mat = new BABYLON.StandardMaterial(name, scene);
            mat.diffuseColor = BABYLON.Color3.FromHexString(hex);
            mat.emissiveColor = BABYLON.Color3.FromHexString(emissiveHex);
            mat.specularColor = new BABYLON.Color3(0.5, 0.5, 0.5);
            mat.alpha = alpha;
            return mat;
        };

        // Positive Gate (Glowing Emerald & Gold)
        this.materials.posFrame = createMat("matPosFrame", "#06d6a0", "#024430");
        this.materials.posCurtain = createMat("matPosCurtain", "#06d6a0", "#06d6a0", 0.65);

        // Negative Gate (Glowing Crimson & Dark Purple)
        this.materials.negFrame = createMat("matNegFrame", "#d90429", "#40000c");
        this.materials.negCurtain = createMat("matNegCurtain", "#ef233c", "#ef233c", 0.65);
    }

    clear() {
        const children = this.root.getChildMeshes();
        for (let i = children.length - 1; i >= 0; i--) {
            children[i].dispose();
        }
        this.gatePairs = [];
    }

    spawnGatePair(config) {
        // config: { z, left: { text, delta, isPositive }, right: { text, delta, isPositive }, isMoving: boolean }
        const scene = this.scene;
        const pairRoot = new BABYLON.TransformNode("gatePair_" + config.z, scene);
        pairRoot.parent = this.root;
        pairRoot.position.z = config.z;

        const leftGate = this.createSingleGate(config.left, -1.6, pairRoot);
        const rightGate = this.createSingleGate(config.right, 1.6, pairRoot);

        const gatePairObj = {
            z: config.z,
            left: leftGate,
            right: rightGate,
            isMoving: !!config.isMoving,
            moveSpeed: config.moveSpeed || 1.8,
            moveAmp: config.moveAmp || 0.6,
            initialX: 0,
            active: true,
            root: pairRoot
        };

        this.gatePairs.push(gatePairObj);
    }

    createSingleGate(data, xOffset, parentNode) {
        const scene = this.scene;
        const gateNode = new BABYLON.TransformNode("gate_" + data.text, scene);
        gateNode.parent = parentNode;
        gateNode.position.x = xOffset;

        const isPos = data.isPositive;
        const frameMat = isPos ? this.materials.posFrame : this.materials.negFrame;
        const curtainMat = isPos ? this.materials.posCurtain : this.materials.negCurtain;

        const width = 2.8;
        const height = 3.6;

        // Arch Left Pillar
        const pillarL = BABYLON.MeshBuilder.CreateBox("gPL", { width: 0.18, height: height, depth: 0.22 }, scene);
        pillarL.parent = gateNode;
        pillarL.position = new BABYLON.Vector3(-width / 2, height / 2, 0);
        pillarL.material = frameMat;

        // Arch Right Pillar
        const pillarR = pillarL.clone("gPR");
        pillarR.parent = gateNode;
        pillarR.position.x = width / 2;

        // Arch Top Beam
        const topBeam = BABYLON.MeshBuilder.CreateBox("gBeam", { width: width + 0.18, height: 0.28, depth: 0.26 }, scene);
        topBeam.parent = gateNode;
        topBeam.position = new BABYLON.Vector3(0, height, 0);
        topBeam.material = frameMat;

        // Translucent Energy Curtain
        const curtain = BABYLON.MeshBuilder.CreatePlane("curtain", { width: width - 0.1, height: height - 0.3 }, scene);
        curtain.parent = gateNode;
        curtain.position = new BABYLON.Vector3(0, height / 2, 0);
        curtain.material = curtainMat;

        // Dynamic Texture Billboard Banner with Text & Values
        const bannerWidth = width + 0.2;
        const bannerHeight = 1.0;
        const bannerPlane = BABYLON.MeshBuilder.CreatePlane("bannerPlane", { width: bannerWidth, height: bannerHeight }, scene);
        bannerPlane.parent = gateNode;
        bannerPlane.position = new BABYLON.Vector3(0, height + 0.55, 0);

        const bannerTex = new BABYLON.DynamicTexture("bannerTex_" + data.text, { width: 512, height: 256 }, scene);
        const bannerMat = new BABYLON.StandardMaterial("bannerMat_" + data.text, scene);
        bannerMat.diffuseTexture = bannerTex;
        bannerMat.emissiveColor = new BABYLON.Color3(1, 1, 1);
        bannerMat.backFaceCulling = false;
        bannerPlane.material = bannerMat;

        // Draw onto dynamic texture
        const ctx = bannerTex.getContext();
        ctx.fillStyle = isPos ? "rgba(10, 80, 50, 0.92)" : "rgba(80, 10, 20, 0.92)";
        ctx.fillRect(0, 0, 512, 256);

        // Border highlight
        ctx.strokeStyle = isPos ? "#06d6a0" : "#ef233c";
        ctx.lineWidth = 14;
        ctx.strokeRect(7, 7, 498, 242);

        // Header value: e.g. "+35 GLAMOUR"
        ctx.fillStyle = isPos ? "#ffd166" : "#ffffff";
        ctx.font = "bold 58px sans-serif";
        ctx.textAlign = "center";
        const prefix = data.delta > 0 ? "+" + data.delta : data.delta;
        ctx.fillText(prefix, 256, 95);

        // Subtitle: e.g. "HAUTE GOWN"
        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 44px sans-serif";
        ctx.fillText(data.text, 256, 185);

        bannerTex.update();

        return {
            node: gateNode,
            curtain: curtain,
            x: xOffset,
            width: width,
            data: data
        };
    }

    update(deltaTime, playerPos, onGateTrigger) {
        const time = performance.now() * 0.001;

        for (let i = 0; i < this.gatePairs.length; i++) {
            const pair = this.gatePairs[i];
            if (!pair.active) continue;

            // Handle oscillating moving gates
            if (pair.isMoving) {
                const offset = Math.sin(time * pair.moveSpeed) * pair.moveAmp;
                pair.root.position.x = offset;
            }

            // Check collision with player
            // Player triggers gate when reaching gate's Z position (+/- 0.6 tolerance)
            const zDist = playerPos.z - pair.z;
            if (zDist >= -0.6 && zDist <= 1.2) {
                // Determine which gate player passed through based on X coordinate
                const rootX = pair.root.position.x;
                const leftGateCenterX = rootX + pair.left.x;
                const rightGateCenterX = rootX + pair.right.x;

                const distToLeft = Math.abs(playerPos.x - leftGateCenterX);
                const distToRight = Math.abs(playerPos.x - rightGateCenterX);

                let chosenGate = null;
                if (distToLeft < pair.left.width / 2) {
                    chosenGate = pair.left;
                } else if (distToRight < pair.right.width / 2) {
                    chosenGate = pair.right;
                } else {
                    // Nearest gate if between lanes
                    chosenGate = distToLeft < distToRight ? pair.left : pair.right;
                }

                if (chosenGate) {
                    pair.active = false;
                    // Visual dissolve effect on curtains
                    pair.left.curtain.visibility = 0.2;
                    pair.right.curtain.visibility = 0.2;

                    onGateTrigger(chosenGate.data, chosenGate.node.getAbsolutePosition());
                }
            }
        }
    }
}

window.ChoiceGateManager = ChoiceGateManager;
