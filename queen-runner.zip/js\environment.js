/**
 * 3D Royal Runway Environment for Queen Runner 3D
 * Generates the royal palace catwalk, marble runway, red carpet, palace spires,
 * flowering trees, paparazzi camera flashes, and the Grand Coronation Throne Podium.
 */

class RoyalEnvironment {
    constructor(scene) {
        this.scene = scene;
        this.trackLength = 200;
        this.trackWidth = 6.4;
        this.trackRoot = new BABYLON.TransformNode("envRoot", scene);
        this.paparazziFlashes = [];
        this.confettiLeft = null;
        this.confettiRight = null;
        this.thronePos = new BABYLON.Vector3(0, 0, 0);
        this.materials = {};

        this.initMaterials();
        this.setupLightsAndFog();
    }

    initMaterials() {
        const scene = this.scene;
        const createMat = (name, hex, emissiveHex = "#000000", specularHex = "#333333") => {
            const mat = new BABYLON.StandardMaterial(name, scene);
            mat.diffuseColor = BABYLON.Color3.FromHexString(hex);
            mat.emissiveColor = BABYLON.Color3.FromHexString(emissiveHex);
            mat.specularColor = BABYLON.Color3.FromHexString(specularHex);
            return mat;
        };

        this.materials.marbleFloor = createMat("matMarble", "#f7f7f9", "#111118", "#aaaaaa");
        this.materials.redCarpet = createMat("matCarpet", "#9e0031", "#220008", "#330010");
        this.materials.goldTrim = createMat("matEnvGold", "#ffb703", "#3a2500", "#ffffff");
        this.materials.railGlow = createMat("matRailGlow", "#ff007f", "#880044", "#ffffff");
        this.materials.palaceWall = createMat("matPalace", "#eee2df", "#100d14", "#444444");
        this.materials.palaceRoof = createMat("matRoof", "#3a0ca3", "#120038", "#8888ff");
        this.materials.hedge = createMat("matHedge", "#2d6a4f", "#081c15", "#112211");
        this.materials.sakura = createMat("matSakura", "#ffb3c6", "#331122", "#442233");
        this.materials.wood = createMat("matWood", "#582f0e", "#100800", "#111111");
        this.materials.throneVelvet = createMat("matThroneVelvet", "#d90429", "#330008", "#660011");
        this.materials.flash = createMat("matFlash", "#ffffff", "#ffffff", "#ffffff");
    }

    setupLightsAndFog() {
        const scene = this.scene;
        scene.clearColor = BABYLON.Color4.FromHexString("#2b0938ff"); // Twilight Royal Magenta Sky
        scene.fogMode = BABYLON.Scene.FOGMODE_LINEAR;
        scene.fogColor = BABYLON.Color3.FromHexString("#2b0938");
        scene.fogStart = 60.0;
        scene.fogEnd = 180.0;

        // Hemispheric Ambient Light (Royal tint)
        const hemi = new BABYLON.HemisphericLight("hemiLight", new BABYLON.Vector3(0, 1, 0), scene);
        hemi.intensity = 0.85;
        hemi.diffuse = BABYLON.Color3.FromHexString("#ffffff");
        hemi.groundColor = BABYLON.Color3.FromHexString("#3a184a");

        // Directional Sun / Runway Spotlight
        const dir = new BABYLON.DirectionalLight("dirLight", new BABYLON.Vector3(-0.4, -1, 0.6), scene);
        dir.position = new BABYLON.Vector3(10, 30, -20);
        dir.intensity = 0.95;
        dir.diffuse = BABYLON.Color3.FromHexString("#fff6ea");
    }

    buildTrack(trackLength) {
        this.trackLength = trackLength;

        // Clean up previous meshes under trackRoot
        const children = this.trackRoot.getChildMeshes();
        for (let i = children.length - 1; i >= 0; i--) {
            children[i].dispose();
        }
        this.paparazziFlashes = [];

        const scene = this.scene;
        const totalZ = trackLength;

        // 1. Elevated Marble Base Runway
        const runway = BABYLON.MeshBuilder.CreateBox("runwayBase", {
            width: this.trackWidth,
            height: 0.8,
            depth: totalZ
        }, scene);
        runway.parent = this.trackRoot;
        runway.position = new BABYLON.Vector3(0, -0.4, totalZ / 2);
        runway.material = this.materials.marbleFloor;

        // 2. Velvet Red Carpet Runner in Center
        const carpet = BABYLON.MeshBuilder.CreateBox("redCarpet", {
            width: 3.2,
            height: 0.82,
            depth: totalZ
        }, scene);
        carpet.parent = this.trackRoot;
        carpet.position = new BABYLON.Vector3(0, -0.39, totalZ / 2);
        carpet.material = this.materials.redCarpet;

        // 3. Golden Borders and Glowing Neon Rails along runway edges
        const railL = BABYLON.MeshBuilder.CreateBox("railL", {
            width: 0.18,
            height: 0.88,
            depth: totalZ
        }, scene);
        railL.parent = this.trackRoot;
        railL.position = new BABYLON.Vector3(-this.trackWidth / 2, -0.36, totalZ / 2);
        railL.material = this.materials.railGlow;

        const railR = railL.clone("railR");
        railR.parent = this.trackRoot;
        railR.position.x = this.trackWidth / 2;

        // Golden Carpet Edge Lines
        const goldStripeL = BABYLON.MeshBuilder.CreateBox("goldStripeL", {
            width: 0.12,
            height: 0.83,
            depth: totalZ
        }, scene);
        goldStripeL.parent = this.trackRoot;
        goldStripeL.position = new BABYLON.Vector3(-1.6, -0.38, totalZ / 2);
        goldStripeL.material = this.materials.goldTrim;

        const goldStripeR = goldStripeL.clone("goldStripeR");
        goldStripeR.parent = this.trackRoot;
        goldStripeR.position.x = 1.6;

        // 4. Scenery: Royal Castle Towers, Trees, Lamp Posts, and Cheering Flashlights
        const spacing = 18;
        const count = Math.floor(totalZ / spacing);

        for (let i = 1; i < count; i++) {
            const zPos = i * spacing;

            // Side Balustrades with glowing golden orbs
            [-this.trackWidth / 2, this.trackWidth / 2].forEach((xSide, idx) => {
                const post = BABYLON.MeshBuilder.CreateCylinder("post_" + i + "_" + idx, {
                    height: 1.1,
                    diameter: 0.22
                }, scene);
                post.parent = this.trackRoot;
                post.position = new BABYLON.Vector3(xSide, 0.45, zPos);
                post.material = this.materials.goldTrim;

                const orb = BABYLON.MeshBuilder.CreateSphere("orb_" + i + "_" + idx, {
                    diameter: 0.32
                }, scene);
                orb.parent = post;
                orb.position.y = 0.65;
                orb.material = this.materials.railGlow;
            });

            // Royal Palaces / Towers along the perimeter
            const towerLeft = this.createCastleTower(new BABYLON.Vector3(-8.5 - (i % 2) * 2, 0, zPos));
            towerLeft.parent = this.trackRoot;

            const towerRight = this.createCastleTower(new BABYLON.Vector3(8.5 + (i % 2) * 2, 0, zPos + 5));
            towerRight.parent = this.trackRoot;

            // Flowering Cherry Blossom / Golden Topiary Trees
            const treeL = this.createRoyalTree(new BABYLON.Vector3(-5.2, 0, zPos - 4), i % 2 === 0);
            treeL.parent = this.trackRoot;

            const treeR = this.createRoyalTree(new BABYLON.Vector3(5.2, 0, zPos + 4), i % 2 !== 0);
            treeR.parent = this.trackRoot;

            // Paparazzi Flash Points
            [-4.5, 4.5].forEach((px, pidx) => {
                const flashMesh = BABYLON.MeshBuilder.CreateSphere("paparazzi_" + i + "_" + pidx, {
                    diameter: 0.35
                }, scene);
                flashMesh.parent = this.trackRoot;
                flashMesh.position = new BABYLON.Vector3(px, 0.8 + Math.random() * 0.8, zPos + (Math.random() - 0.5) * 4);
                flashMesh.material = this.materials.flash;
                flashMesh.setEnabled(false); // only flashes momentarily
                this.paparazziFlashes.push({
                    mesh: flashMesh,
                    timer: Math.random() * 2.5
                });
            });

            // Milestone Royal Archways every 50m
            if (i > 0 && i % 3 === 0) {
                const arch = this.createRoyalArchway(zPos);
                arch.parent = this.trackRoot;
            }
        }

        // 5. The Grand Coronation Podium & Multiplier Stairs
        this.buildCoronationPodium(totalZ);
    }

    createCastleTower(pos) {
        const scene = this.scene;
        const towerRoot = new BABYLON.TransformNode("tower", scene);
        towerRoot.position = pos;

        // Tower Body
        const body = BABYLON.MeshBuilder.CreateCylinder("tBody", {
            height: 12,
            diameter: 3.5,
            tessellation: 16
        }, scene);
        body.parent = towerRoot;
        body.position.y = 5.5;
        body.material = this.materials.palaceWall;

        // Conical Roof
        const roof = BABYLON.MeshBuilder.CreateCylinder("tRoof", {
            height: 6.5,
            diameterTop: 0.1,
            diameterBottom: 4.2,
            tessellation: 16
        }, scene);
        roof.parent = towerRoot;
        roof.position.y = 14.2;
        roof.material = this.materials.palaceRoof;

        // Royal Pennant / Flag
        const flagPole = BABYLON.MeshBuilder.CreateCylinder("flagPole", { height: 2.2, diameter: 0.08 }, scene);
        flagPole.parent = roof;
        flagPole.position.y = 4.0;
        flagPole.material = this.materials.goldTrim;

        const flag = BABYLON.MeshBuilder.CreateBox("flag", { width: 0.04, height: 0.8, depth: 1.2 }, scene);
        flag.parent = flagPole;
        flag.position = new BABYLON.Vector3(0, 0.4, 0.6);
        flag.material = this.materials.railGlow;

        return towerRoot;
    }

    createRoyalTree(pos, isSakura = true) {
        const scene = this.scene;
        const treeRoot = new BABYLON.TransformNode("tree", scene);
        treeRoot.position = pos;

        const trunk = BABYLON.MeshBuilder.CreateCylinder("trunk", { height: 2.5, diameterTop: 0.3, diameterBottom: 0.5 }, scene);
        trunk.parent = treeRoot;
        trunk.position.y = 1.25;
        trunk.material = this.materials.wood;

        const foliageMat = isSakura ? this.materials.sakura : this.materials.hedge;
        const foliage = BABYLON.MeshBuilder.CreateSphere("foliage", { diameterX: 2.4, diameterY: 2.8, diameterZ: 2.4 }, scene);
        foliage.parent = treeRoot;
        foliage.position.y = 3.2;
        foliage.material = foliageMat;

        return treeRoot;
    }

    createRoyalArchway(zPos) {
        const scene = this.scene;
        const archRoot = new BABYLON.TransformNode("milestoneArch", scene);
        archRoot.position = new BABYLON.Vector3(0, 0, zPos);

        const pillarL = BABYLON.MeshBuilder.CreateCylinder("pL", { height: 6.5, diameter: 0.5 }, scene);
        pillarL.parent = archRoot;
        pillarL.position = new BABYLON.Vector3(-this.trackWidth / 2 - 0.2, 3.2, 0);
        pillarL.material = this.materials.palaceWall;

        const pillarR = pillarL.clone("pR");
        pillarR.parent = archRoot;
        pillarR.position.x = this.trackWidth / 2 + 0.2;

        const crossbeam = BABYLON.MeshBuilder.CreateBox("cBeam", { width: this.trackWidth + 1.2, height: 0.7, depth: 0.7 }, scene);
        crossbeam.parent = archRoot;
        crossbeam.position = new BABYLON.Vector3(0, 6.2, 0);
        crossbeam.material = this.materials.goldTrim;

        // Royal Crest on Arch
        const crest = BABYLON.MeshBuilder.CreateCylinder("crest", { height: 0.2, diameter: 1.2 }, scene);
        crest.parent = crossbeam;
        crest.rotation.x = Math.PI / 2;
        crest.position.y = 0.5;
        crest.material = this.materials.railGlow;

        return archRoot;
    }

    buildCoronationPodium(totalZ) {
        const scene = this.scene;
        const podiumRoot = new BABYLON.TransformNode("podiumRoot", scene);
        podiumRoot.position = new BABYLON.Vector3(0, 0, totalZ);
        podiumRoot.parent = this.trackRoot;

        // Multiplier Staircase (5 Tiers of Glory)
        const stepCount = 5;
        const stepWidth = 4.8;
        const stepDepth = 3.5;
        const stepHeight = 0.45;
        const multipliers = ["1.0x", "1.5x", "2.0x", "3.0x", "5.0x QUEEN"];

        this.steps = [];

        for (let i = 0; i < stepCount; i++) {
            const stepZ = i * stepDepth + 2.0;
            const stepY = i * stepHeight + 0.2;

            const stepMesh = BABYLON.MeshBuilder.CreateBox("step_" + i, {
                width: stepWidth - i * 0.25,
                height: stepHeight + 0.2,
                depth: stepDepth
            }, scene);
            stepMesh.parent = podiumRoot;
            stepMesh.position = new BABYLON.Vector3(0, stepY, stepZ);
            stepMesh.material = i === 4 ? this.materials.goldTrim : this.materials.redCarpet;

            // Border Trim
            const trim = BABYLON.MeshBuilder.CreateBox("stepTrim_" + i, {
                width: stepWidth - i * 0.25 + 0.2,
                height: 0.08,
                depth: stepDepth + 0.2
            }, scene);
            trim.parent = stepMesh;
            trim.position.y = (stepHeight + 0.2) / 2;
            trim.material = this.materials.goldTrim;

            this.steps.push({
                y: stepY + stepHeight / 2 + 0.2,
                z: totalZ + stepZ,
                mult: multipliers[i],
                mesh: stepMesh
            });
        }

        // Elevated Throne Platform at the Top
        const topStep = this.steps[stepCount - 1];
        const throneZ = topStep.z + 4.5;
        const throneY = topStep.y + 0.4;
        this.thronePos = new BABYLON.Vector3(0, throneY, throneZ);

        const dais = BABYLON.MeshBuilder.CreateCylinder("dais", {
            height: 0.8,
            diameter: 7.0,
            tessellation: 24
        }, scene);
        dais.parent = this.trackRoot;
        dais.position = new BABYLON.Vector3(0, throneY - 0.4, throneZ);
        dais.material = this.materials.marbleFloor;

        // Grand Golden Royal Throne
        const throneSeat = BABYLON.MeshBuilder.CreateBox("throneSeat", { width: 1.8, height: 0.6, depth: 1.4 }, scene);
        throneSeat.parent = this.trackRoot;
        throneSeat.position = new BABYLON.Vector3(0, throneY + 0.3, throneZ + 1.2);
        throneSeat.material = this.materials.throneVelvet;

        const throneBack = BABYLON.MeshBuilder.CreateBox("throneBack", { width: 1.8, height: 2.2, depth: 0.3 }, scene);
        throneBack.parent = throneSeat;
        throneBack.position = new BABYLON.Vector3(0, 1.3, 0.6);
        throneBack.material = this.materials.goldTrim;

        const throneCushion = BABYLON.MeshBuilder.CreateBox("throneCushion", { width: 1.4, height: 1.8, depth: 0.1 }, scene);
        throneCushion.parent = throneBack;
        throneCushion.position = new BABYLON.Vector3(0, 0, -0.16);
        throneCushion.material = this.materials.throneVelvet;

        // Majestic Columns framing the throne
        [-3.2, 3.2].forEach((cx, cidx) => {
            const col = BABYLON.MeshBuilder.CreateCylinder("tCol_" + cidx, { height: 7.5, diameter: 0.6 }, scene);
            col.parent = this.trackRoot;
            col.position = new BABYLON.Vector3(cx, throneY + 3.4, throneZ + 0.5);
            col.material = this.materials.palaceWall;

            const colCap = BABYLON.MeshBuilder.CreateCylinder("colCap_" + cidx, { height: 0.4, diameter: 0.9 }, scene);
            colCap.parent = col;
            colCap.position.y = 3.6;
            colCap.material = this.materials.goldTrim;
        });

        // Setup Confetti Cannons
        this.initConfettiCannons(new BABYLON.Vector3(-3.0, throneY + 1.0, throneZ), new BABYLON.Vector3(3.0, throneY + 1.0, throneZ));
    }

    initConfettiCannons(leftPos, rightPos) {
        const scene = this.scene;
        const particleTexture = new BABYLON.Texture("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAUUlEQVR42mP8z8BQDMRMDAwM/8nBAQxMDFgB/v///5+RkRFE/P///38wTBoGhmA0/mDE5h5sGBsYjV+MDQx5YBgNJseAEH8xYFGI399DAgA0rQ11f1k3GAAAAABJRU5ErkJggg==", scene);

        const createCannon = (name, pos, xDir) => {
            const ps = new BABYLON.ParticleSystem(name, 250, scene);
            ps.particleTexture = particleTexture;
            ps.emitter = pos;
            ps.minEmitBox = new BABYLON.Vector3(-0.2, 0, -0.2);
            ps.maxEmitBox = new BABYLON.Vector3(0.2, 0, 0.2);

            ps.color1 = new BABYLON.Color4(1.0, 0.2, 0.5, 1.0);
            ps.color2 = new BABYLON.Color4(1.0, 0.85, 0.0, 1.0);
            ps.colorDead = new BABYLON.Color4(0.2, 0.8, 1.0, 0.0);

            ps.minSize = 0.15;
            ps.maxSize = 0.35;
            ps.minLifeTime = 1.2;
            ps.maxLifeTime = 2.4;
            ps.emitRate = 140;

            ps.gravity = new BABYLON.Vector3(0, -4.5, 0);
            ps.direction1 = new BABYLON.Vector3(xDir * 1.5, 8.5, 1.0);
            ps.direction2 = new BABYLON.Vector3(xDir * 3.5, 12.0, -1.0);
            ps.minEmitPower = 5.0;
            ps.maxEmitPower = 9.0;
            return ps;
        };

        this.confettiLeft = createCannon("confettiL", leftPos, 1);
        this.confettiRight = createCannon("confettiR", rightPos, -1);
    }

    fireConfetti() {
        if (this.confettiLeft) this.confettiLeft.start();
        if (this.confettiRight) this.confettiRight.start();
        if (window.gameAudio) window.gameAudio.playConfetti();
    }

    stopConfetti() {
        if (this.confettiLeft) this.confettiLeft.stop();
        if (this.confettiRight) this.confettiRight.stop();
    }

    update(deltaTime) {
        // Update Paparazzi Camera Flashes
        for (let i = 0; i < this.paparazziFlashes.length; i++) {
            const item = this.paparazziFlashes[i];
            item.timer -= deltaTime;
            if (item.timer <= 0) {
                // Flash on
                item.mesh.setEnabled(true);
                item.mesh.scaling.setAll(1.5 + Math.random() * 0.8);
                // Reset timer (random between 1.0 and 3.5s)
                item.timer = 1.0 + Math.random() * 2.5;

                // Flash off in 0.08s
                setTimeout(() => {
                    if (item.mesh && !item.mesh.isDisposed()) {
                        item.mesh.setEnabled(false);
                    }
                }, 80);
            }
        }
    }
}

window.RoyalEnvironment = RoyalEnvironment;
