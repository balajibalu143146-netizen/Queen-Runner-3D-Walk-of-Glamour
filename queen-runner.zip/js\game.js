/**
 * Main Game Controller for Queen Runner 3D
 * Connects Babylon.js engine, character rig, runway environment, choice gates,
 * collectibles, camera, touch/keyboard controls, audio, and UI state machines.
 */

class QueenRunnerGame {
    constructor() {
        this.canvas = document.getElementById("renderCanvas");
        this.engine = null;
        this.scene = null;
        this.camera = null;

        // Subsystems
        this.character = null;
        this.environment = null;
        this.gateManager = null;
        this.collectiblesManager = null;

        // Gameplay State
        this.state = "START"; // "START", "RUNNING", "FINALE", "VICTORY", "GAMEOVER", "PAUSED"
        this.currentLevelIndex = 0;
        this.currentLevel = GAME_LEVELS[0];

        this.playerX = 0;
        this.playerZ = 0;
        this.targetX = 0;
        this.steeringVelocity = 0;

        this.glamour = 30; // Starts at casual/trendy threshold
        this.coinsCollected = 0;
        this.totalCoins = parseInt(localStorage.getItem("queen_total_coins") || "0", 10);
        this.maxUnlockedLevel = parseInt(localStorage.getItem("queen_max_level") || "1", 10);

        // Control input state
        this.isPointerDown = false;
        this.lastPointerX = 0;
        this.keys = {};

        // Finale progression
        this.finaleTimer = 0;
        this.finaleStepReached = 0;
        this.targetFinaleZ = 0;

        // UI references
        this.ui = {
            startScreen: document.getElementById("startScreen"),
            victoryModal: document.getElementById("victoryModal"),
            gameoverModal: document.getElementById("gameoverModal"),
            levelSelectModal: document.getElementById("levelSelectModal"),
            hud: document.getElementById("hud"),
            glamourFill: document.getElementById("glamourFill"),
            glamourLabel: document.getElementById("glamourLabel"),
            glamourPoints: document.getElementById("glamourPoints"),
            coinCount: document.getElementById("coinCount"),
            levelBadge: document.getElementById("levelBadge"),
            progressBarFill: document.getElementById("progressBarFill"),
            floatingContainer: document.getElementById("floatingContainer"),
            btnAudio: document.getElementById("btnAudio")
        };

        this.initEngine();
        this.setupInputListeners();
        this.setupUIListeners();
        this.loadLevel(this.currentLevelIndex);
        this.updateHUD();
    }

    initEngine() {
        this.engine = new BABYLON.Engine(this.canvas, true, {
            preserveDrawingBuffer: false,
            stencil: false,
            powerPreference: "high-performance"
        });

        this.scene = new BABYLON.Scene(this.engine);

        // Third-person Chase Camera
        this.camera = new BABYLON.UniversalCamera("queenCamera", new BABYLON.Vector3(0, 3.8, -7.5), this.scene);
        this.camera.setTarget(new BABYLON.Vector3(0, 1.8, 4.0));
        this.camera.fov = 0.95;

        // Instantiate subsystems
        this.environment = new RoyalEnvironment(this.scene);
        this.character = new QueenCharacter(this.scene);
        this.gateManager = new ChoiceGateManager(this.scene);
        this.collectiblesManager = new CollectiblesManager(this.scene);

        // Start render loop
        this.engine.runRenderLoop(() => {
            const deltaTime = Math.min(this.engine.getDeltaTime() * 0.001, 0.05);
            this.update(deltaTime);
            this.scene.render();
        });

        window.addEventListener("resize", () => {
            this.engine.resize();
        });
    }

    setupInputListeners() {
        // Touch & Mouse Drag Steering (Mobile & Desktop)
        const onDown = (clientX) => {
            if (this.state === "START") {
                this.startGame();
            }
            this.isPointerDown = true;
            this.lastPointerX = clientX;
        };

        const onMove = (clientX) => {
            if (!this.isPointerDown || this.state !== "RUNNING") return;
            const deltaX = clientX - this.lastPointerX;
            this.lastPointerX = clientX;

            const sensitivity = (window.innerWidth < 768) ? 0.014 : 0.010;
            this.targetX += deltaX * sensitivity;
            this.targetX = Math.max(-2.5, Math.min(2.5, this.targetX));
        };

        const onUp = () => {
            this.isPointerDown = false;
        };

        this.canvas.addEventListener("pointerdown", (e) => onDown(e.clientX));
        window.addEventListener("pointermove", (e) => onMove(e.clientX));
        window.addEventListener("pointerup", onUp);
        window.addEventListener("pointercancel", onUp);

        // Keyboard Controls (A/D, Arrows)
        window.addEventListener("keydown", (e) => {
            this.keys[e.code] = true;
            if (this.state === "START" && (e.code === "Space" || e.code === "KeyA" || e.code === "KeyD" || e.code === "ArrowLeft" || e.code === "ArrowRight")) {
                this.startGame();
            }
        });

        window.addEventListener("keyup", (e) => {
            this.keys[e.code] = false;
        });
    }

    setupUIListeners() {
        document.getElementById("btnPlay").addEventListener("click", () => this.startGame());
        document.getElementById("btnLevelSelect").addEventListener("click", () => this.openLevelSelect());
        document.getElementById("btnCloseLevelSelect").addEventListener("click", () => this.closeLevelSelect());

        document.getElementById("btnNextLevel").addEventListener("click", () => {
            this.nextLevel();
        });

        document.getElementById("btnReplay").addEventListener("click", () => {
            this.restartLevel();
        });

        document.getElementById("btnRetry").addEventListener("click", () => {
            this.restartLevel();
        });

        this.ui.btnAudio.addEventListener("click", () => {
            const isMuted = window.gameAudio.toggleMute();
            this.ui.btnAudio.textContent = isMuted ? "🔇" : "🔊";
        });
    }

    loadLevel(index) {
        this.currentLevelIndex = index;
        this.currentLevel = GAME_LEVELS[index];

        // Reset player positions
        this.playerX = 0;
        this.playerZ = 0;
        this.targetX = 0;
        this.steeringVelocity = 0;
        this.glamour = 35; // Start with decent glamour
        this.coinsCollected = 0;
        this.state = "START";
        this.character.isCelebrating = false;
        this.character.root.position = new BABYLON.Vector3(0, 0, 0);
        this.character.root.rotation.setAll(0);

        // Update Subsystems
        this.environment.buildTrack(this.currentLevel.length);
        this.environment.stopConfetti();

        // Spawn choice gates
        this.gateManager.clear();
        this.currentLevel.gates.forEach(g => this.gateManager.spawnGatePair(g));

        // Spawn coins & collectibles
        this.collectiblesManager.clear();
        this.currentLevel.coins.forEach(c => {
            if (c.type === "line") {
                this.collectiblesManager.spawnCoinLine(c.x, c.startZ, c.count);
            } else if (c.type === "arc") {
                this.collectiblesManager.spawnCoinArc(c.startX, c.endX, c.startZ, c.count);
            }
        });

        // Spawn Gems
        if (this.currentLevel.gems) {
            this.currentLevel.gems.forEach(gm => this.collectiblesManager.spawnGem(gm.x, gm.z, gm.type));
        }

        // Spawn Hazards
        if (this.currentLevel.hazards) {
            this.currentLevel.hazards.forEach(h => this.collectiblesManager.spawnMudHazard(h.x, h.z));
        }

        // Update character outfit based on initial glamour
        this.syncCharacterOutfit();

        // UI Reset
        this.ui.startScreen.style.display = "flex";
        this.ui.victoryModal.style.display = "none";
        this.ui.gameoverModal.style.display = "none";
        document.getElementById("startLevelTitle").textContent = `LEVEL ${this.currentLevel.id}: ${this.currentLevel.title.toUpperCase()}`;
        document.getElementById("startLevelDesc").textContent = this.currentLevel.description;

        this.updateHUD();
    }

    startGame() {
        if (this.state !== "START") return;
        this.state = "RUNNING";
        this.ui.startScreen.style.display = "none";
        window.gameAudio.resume();
        window.gameAudio.startBGM();
    }

    restartLevel() {
        this.loadLevel(this.currentLevelIndex);
        this.startGame();
    }

    nextLevel() {
        const nextIdx = (this.currentLevelIndex + 1) % GAME_LEVELS.length;
        this.loadLevel(nextIdx);
        this.startGame();
    }

    openLevelSelect() {
        const container = document.getElementById("levelCardsContainer");
        container.innerHTML = "";

        GAME_LEVELS.forEach((lvl, idx) => {
            const card = document.createElement("button");
            const isUnlocked = lvl.id <= this.maxUnlockedLevel;
            card.className = `level-card ${isUnlocked ? "unlocked" : "locked"}`;
            card.innerHTML = `
                <div class="lvl-num">Level ${lvl.id}</div>
                <div class="lvl-name">${lvl.title}</div>
                <div class="lvl-sub">${lvl.subtitle}</div>
                <div class="lvl-status">${isUnlocked ? "👑 Play" : "🔒 Locked"}</div>
            `;
            if (isUnlocked) {
                card.onclick = () => {
                    this.closeLevelSelect();
                    this.loadLevel(idx);
                };
            }
            container.appendChild(card);
        });

        this.ui.levelSelectModal.style.display = "flex";
    }

    closeLevelSelect() {
        this.ui.levelSelectModal.style.display = "none";
    }

    // --- GAME LOOP UPDATE ---
    update(deltaTime) {
        if (this.state === "RUNNING") {
            this.updateRunning(deltaTime);
        } else if (this.state === "FINALE") {
            this.updateFinale(deltaTime);
        }

        // Always update scenery & character animations
        this.environment.update(deltaTime);
        this.character.update(
            deltaTime,
            this.state === "RUNNING" ? this.currentLevel.speed : 0,
            this.state === "RUNNING",
            this.steeringVelocity
        );

        this.updateCamera(deltaTime);
    }

    updateRunning(deltaTime) {
        // 1. Keyboard continuous steering
        const kbSpeed = 10.0;
        if (this.keys["ArrowLeft"] || this.keys["KeyA"]) {
            this.targetX -= kbSpeed * deltaTime;
        }
        if (this.keys["ArrowRight"] || this.keys["KeyD"]) {
            this.targetX += kbSpeed * deltaTime;
        }
        this.targetX = Math.max(-2.5, Math.min(2.5, this.targetX));

        // Smooth physics-damped horizontal interpolation
        const prevX = this.playerX;
        this.playerX += (this.targetX - this.playerX) * Math.min(1.0, deltaTime * 14.0);
        this.steeringVelocity = (this.playerX - prevX) / Math.max(0.001, deltaTime);

        // Move forward along the runway
        this.playerZ += this.currentLevel.speed * deltaTime;

        // Sync 3D mesh
        this.character.root.position.x = this.playerX;
        this.character.root.position.z = this.playerZ;

        // Check if reached the end of the runway
        if (this.playerZ >= this.currentLevel.length) {
            this.startFinale();
            return;
        }

        // 2. Choice Gates Collision
        this.gateManager.update(deltaTime, this.character.root.position, (gateData, pos) => {
            this.onGateHit(gateData, pos);
        });

        // 3. Collectibles Collision & Magnetism
        this.collectiblesManager.update(
            deltaTime,
            this.character.root.position,
            (item) => this.onCollectItem(item),
            (hazard) => this.onHitHazard(hazard)
        );

        // Update HUD progress bar
        const progress = Math.min(100, (this.playerZ / this.currentLevel.length) * 100);
        this.ui.progressBarFill.style.width = `${progress}%`;
    }

    onGateHit(gateData, pos) {
        this.glamour = Math.max(0, this.glamour + gateData.delta);

        if (gateData.delta > 0) {
            window.gameAudio.playPositiveGate();
            this.spawnFloatingText(`+${gateData.delta} ${gateData.text}!`, "#06d6a0");
        } else {
            window.gameAudio.playNegativeGate();
            this.character.triggerStumble();
            this.spawnFloatingText(`${gateData.delta} ${gateData.text}!`, "#ef233c");
        }

        this.syncCharacterOutfit();
        this.updateHUD();

        if (this.glamour <= 0) {
            this.triggerGameOver();
        }
    }

    onCollectItem(item) {
        if (item.type === "coin") {
            this.coinsCollected += item.value;
            this.totalCoins += item.value;
            localStorage.setItem("queen_total_coins", this.totalCoins);
            window.gameAudio.playCoin();
            this.spawnFloatingText(`+${item.value}`, "#ffd166");
        } else if (item.type === "gem") {
            this.coinsCollected += item.value;
            this.totalCoins += item.value;
            this.glamour += item.glamourBonus;
            localStorage.setItem("queen_total_coins", this.totalCoins);
            window.gameAudio.playGem();
            this.spawnFloatingText(`💎 +${item.glamourBonus} GLAMOUR!`, "#00f5d4");
            this.syncCharacterOutfit();
        }

        this.updateHUD();
    }

    onHitHazard(hazard) {
        this.glamour = Math.max(0, this.glamour - 15);
        this.character.triggerStumble();
        window.gameAudio.playNegativeGate();
        this.spawnFloatingText("-15 MUD SPLATTER!", "#ff758f");
        this.syncCharacterOutfit();
        this.updateHUD();

        if (this.glamour <= 0) {
            this.triggerGameOver();
        }
    }

    syncCharacterOutfit() {
        // Determine outfit tier based on glamour:
        // Tier 1: 0 - 24
        // Tier 2: 25 - 49
        // Tier 3: 50 - 74
        // Tier 4: 75 - 99
        // Tier 5: 100+
        let newTier = 1;
        if (this.glamour >= 100) newTier = 5;
        else if (this.glamour >= 75) newTier = 4;
        else if (this.glamour >= 50) newTier = 3;
        else if (this.glamour >= 25) newTier = 2;

        if (newTier !== this.character.tier) {
            this.character.applyTier(newTier, true);
            const tierNames = ["", "CASUAL", "STREET CHIC", "GALA DIVA", "PRINCESS", "MAJESTIC QUEEN 👑"];
            this.spawnFloatingText(`👑 ${tierNames[newTier]}!`, "#ffd700");
        }
    }

    // --- CORONATION FINALE ---
    startFinale() {
        this.state = "FINALE";
        this.finaleTimer = 0;
        this.targetX = 0; // Return to center carpet
        window.gameAudio.stopBGM();

        // Calculate final step reached on podium based on glamour tier (1 to 5)
        const tier = this.character.tier;
        this.finaleStepReached = Math.min(tier, 5);

        const targetStep = (this.environment.steps && this.environment.steps[this.finaleStepReached - 1]) || { z: this.currentLevel.length + 8 };
        this.targetFinaleZ = targetStep.z;
    }

    updateFinale(deltaTime) {
        this.finaleTimer += deltaTime;

        // Smoothly walk player up the multiplier stairs towards the throne
        const walkSpeed = 5.0;
        if (this.playerZ < this.targetFinaleZ) {
            this.playerZ += walkSpeed * deltaTime;
            this.playerX += (0 - this.playerX) * Math.min(1.0, deltaTime * 8);

            // Interpolate elevation Y based on distance along steps
            const stepY = (this.finaleStepReached - 1) * 0.45;
            this.character.root.position.y = Math.min(stepY + 0.2, this.character.root.position.y + deltaTime * 2.5);

            this.character.root.position.x = this.playerX;
            this.character.root.position.z = this.playerZ;
        } else {
            // Reached pinnacle of their glamour tier!
            if (!this.character.isCelebrating) {
                this.character.triggerCelebration();
                this.environment.fireConfetti();
                window.gameAudio.playCoronationFanfare();

                // Rotate Queen smoothly to face the camera and kingdom!
                this.character.root.rotation.y = Math.PI;

                setTimeout(() => {
                    this.showVictoryModal();
                }, 2200);
            }
        }
    }

    showVictoryModal() {
        this.state = "VICTORY";
        const tier = this.character.tier;
        const multipliers = [1.0, 1.5, 2.0, 3.0, 5.0];
        const mult = multipliers[tier - 1];
        const bonusCoins = Math.round(this.coinsCollected * mult);

        // Update unlocked levels
        if (this.currentLevel.id >= this.maxUnlockedLevel && this.currentLevel.id < GAME_LEVELS.length) {
            this.maxUnlockedLevel = this.currentLevel.id + 1;
            localStorage.setItem("queen_max_level", this.maxUnlockedLevel);
        }

        // Stars rating (1 to 3)
        let stars = 1;
        if (this.glamour >= this.currentLevel.targetGlamour) stars = 3;
        else if (this.glamour >= this.currentLevel.targetGlamour * 0.7) stars = 2;

        const starDisplay = "⭐".repeat(stars) + "☆".repeat(3 - stars);
        const titles = ["", "RAGS TO RUNWAY", "TRENDY STYLIST", "GLAMOUR ICON", "ROYAL PRINCESS", "MAJESTIC QUEEN 👑"];

        document.getElementById("victoryTitle").textContent = titles[tier];
        document.getElementById("victoryStars").textContent = starDisplay;
        document.getElementById("victoryGlamour").textContent = `${this.glamour} Glamour`;
        document.getElementById("victoryCoins").textContent = `💰 ${this.coinsCollected} x ${mult} = ${bonusCoins} Coins`;

        // If level 5 complete, show special Queen message
        if (this.currentLevel.id === 5 && tier >= 4) {
            document.getElementById("victorySubtitle").textContent = "🎉 Congratulations! You have conquered all 5 levels and been crowned Empress of the Catwalk!";
        } else {
            document.getElementById("victorySubtitle").textContent = "You dazzled the royal court with undeniable style!";
        }

        this.ui.victoryModal.style.display = "flex";
    }

    triggerGameOver() {
        this.state = "GAMEOVER";
        window.gameAudio.stopBGM();
        this.character.triggerStumble();
        this.ui.gameoverModal.style.display = "flex";
    }

    // --- CAMERA CHASE CONTROLLER ---
    updateCamera(deltaTime) {
        const charPos = this.character.root.position;

        if (this.state === "FINALE" && this.character.isCelebrating) {
            // Cinematic frontal coronation camera shot!
            const targetCamPos = new BABYLON.Vector3(
                charPos.x * 0.3,
                charPos.y + 1.8,
                charPos.z + 5.5
            );
            this.camera.position = BABYLON.Vector3.Lerp(this.camera.position, targetCamPos, Math.min(1.0, deltaTime * 3.5));
            this.camera.setTarget(new BABYLON.Vector3(charPos.x, charPos.y + 1.2, charPos.z));
        } else {
            // Standard Third-person chase camera
            const targetCamPos = new BABYLON.Vector3(
                charPos.x * 0.45,
                charPos.y + 3.6,
                charPos.z - 7.0
            );

            this.camera.position = BABYLON.Vector3.Lerp(this.camera.position, targetCamPos, Math.min(1.0, deltaTime * 12.0));
            this.camera.setTarget(new BABYLON.Vector3(charPos.x * 0.25, charPos.y + 1.7, charPos.z + 4.0));
        }
    }

    // --- HUD & VISUAL FEEDBACK ---
    updateHUD() {
        const tier = this.character ? this.character.tier : 1;
        const tierLabels = ["", "CASUAL", "TRENDY", "GLAMOUR", "PRINCESS", "QUEEN 👑"];

        this.ui.levelBadge.textContent = `LEVEL ${this.currentLevel.id}`;
        this.ui.coinCount.textContent = this.coinsCollected;
        this.ui.glamourPoints.textContent = `${this.glamour} PTS`;
        this.ui.glamourLabel.textContent = tierLabels[tier];

        // Glamour progress bar percentage (0 to 120 scale)
        const pct = Math.min(100, Math.max(5, (this.glamour / 120) * 100));
        this.ui.glamourFill.style.width = `${pct}%`;

        // Color coding based on tier
        const colors = ["#888c94", "#70d6ff", "#e01a4f", "#06d6a0", "#ffd700"];
        this.ui.glamourFill.style.background = `linear-gradient(90deg, #ff007f, ${colors[tier - 1]})`;
    }

    spawnFloatingText(text, color = "#ffd166") {
        const popup = document.createElement("div");
        popup.className = "floating-text";
        popup.textContent = text;
        popup.style.color = color;
        popup.style.left = "50%";
        popup.style.top = "45%";

        this.ui.floatingContainer.appendChild(popup);

        setTimeout(() => {
            if (popup.parentNode) {
                popup.parentNode.removeChild(popup);
            }
        }, 1100);
    }
}

// Boot game when DOM is loaded
window.addEventListener("DOMContentLoaded", () => {
    window.queenGame = new QueenRunnerGame();
});
